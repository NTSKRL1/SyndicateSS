export const translations = {
  en: {
    welcome: {
      title: 'SYNDICATE',
      subtitle: 'Enter your codename to join the game',
      enterGame: 'Enter Game',
      viewRoleGuide: 'View Role Guide',
      agreeToRules: 'By entering, you agree to play by the rules',
      roleGuide: 'Role Guide',
      enterCodename: 'Enter your codename'
    },
    lobby: {
      welcome: 'Welcome',
      availableRooms: 'Available Rooms',
      createRoom: 'Create Room',
      joinRoom: 'Join Room',
      enterRoomCode: 'Enter room code',
      roomName: 'Enter room name',
      players: 'players',
      noRooms: 'No rooms available',
      createRoomPrompt: 'Create a room to start playing!',
      alreadyJoined: 'Already Joined',
      join: 'Join',
      create: 'Create',
      cancel: 'Cancel',
      copied: 'Copied!',
      copyCode: 'Copy Code'
    },
    categories: {
      syndicate: 'Syndicate',
      saviors: 'Saviors',
      neutral: 'Neutral'
    },
    roles: {
      bossSyndicate: {
        name: 'Boss Syndicate',
        description: 'Leader of the Syndicate. Can see all Syndicate members and coordinate attacks. Can attempt assassinations during voting phase by guessing a player\'s role.'
      },
      lesserSyndicate: {
        name: 'Lesser Syndicate',
        description: 'Member of the Syndicate. Can perform basic night kills and communicate secretly with other Syndicate members.'
      },
      classicSyndicate: {
        name: 'Classic Syndicate',
        description: 'A basic Syndicate member with no special abilities beyond night kills and Syndicate chat.'
      },
      flash: {
        name: 'Flash',
        description: 'Can blind all players during the night, preventing any night actions from occurring.'
      },
      vanished: {
        name: 'Vanished',
        description: 'Can become invisible twice per game, hiding from all investigative abilities for one night.'
      },
      blackmailer: {
        name: 'Blackmailer',
        description: 'Can prevent one player from voting or speaking during the next day phase.'
      },
      detective: {
        name: 'Detective',
        description: 'Can investigate one player each night to determine if they performed suspicious activities.'
      },
      seer: {
        name: 'Seer',
        description: 'Can reveal the exact role of one player each night. Limited to three uses per game.'
      },
      trapper: {
        name: 'Trapper',
        description: 'Can set a trap during the morning phase using a trojan message.'
      },
      veteran: {
        name: 'Veteran',
        description: 'Can go on alert three times per game, killing all players who visit them that night.'
      },
      jailor: {
        name: 'Jailor',
        description: 'Can detain one player during the night for questioning and execution.'
      },
      classicSavior: {
        name: 'Classic Savior',
        description: 'A basic town member with no special abilities.'
      },
      vigilante: {
        name: 'Vigilante',
        description: 'Can shoot one player during the voting phase. Dies of guilt if they kill a fellow Savior.'
      },
      doctor: {
        name: 'Doctor',
        description: 'Can heal one player each night, preventing their death.'
      },
      manipulator: {
        name: 'Manipulator',
        description: 'Must get their target voted out to win. Cannot control other players but can use social manipulation.'
      },
      werewolf: {
        name: 'Werewolf',
        description: 'Can rampage at one player\'s house during full moon nights, killing them and all their visitors.'
      },
      arsonist: {
        name: 'Arsonist',
        description: 'Can douse players in gasoline and ignite all doused players at once.'
      },
      plague: {
        name: 'Plague',
        description: 'Can infect players with a disease that spreads to players they interact with.'
      }
    }
  },
  tr: {
    welcome: {
      title: 'SENDİKA',
      subtitle: 'Oyuna katılmak için kod adınızı girin',
      enterGame: 'Oyuna Gir',
      viewRoleGuide: 'Rol Rehberini Görüntüle',
      agreeToRules: 'Giriş yaparak kuralları kabul etmiş olursunuz',
      roleGuide: 'Rol Rehberi',
      enterCodename: 'Kod adınızı girin'
    },
    lobby: {
      welcome: 'Hoş Geldiniz',
      availableRooms: 'Mevcut Odalar',
      createRoom: 'Oda Oluştur',
      joinRoom: 'Odaya Katıl',
      enterRoomCode: 'Oda kodunu girin',
      roomName: 'Oda adını girin',
      players: 'oyuncu',
      noRooms: 'Mevcut oda yok',
      createRoomPrompt: 'Oynamaya başlamak için bir oda oluşturun!',
      alreadyJoined: 'Zaten Katıldınız',
      join: 'Katıl',
      create: 'Oluştur',
      cancel: 'İptal',
      copied: 'Kopyalandı!',
      copyCode: 'Kodu Kopyala'
    },
    categories: {
      syndicate: 'Sendika',
      saviors: 'Kurtarıcılar',
      neutral: 'Tarafsız'
    },
    roles: {
      bossSyndicate: {
        name: 'Sendika Patronu',
        description: 'Sendikanın lideri. Tüm Sendika üyelerini görebilir ve saldırıları koordine edebilir.'
      },
      lesserSyndicate: {
        name: 'Alt Sendika',
        description: 'Sendika üyesi. Gece öldürme yapabilir ve diğer Sendika üyeleriyle gizlice iletişim kurabilir.'
      },
      classicSyndicate: {
        name: 'Klasik Sendika',
        description: 'Gece öldürme ve Sendika sohbeti dışında özel yetenekleri olmayan temel bir Sendika üyesi.'
      },
      flash: {
        name: 'Flaş',
        description: 'Gece tüm oyuncuları kör edebilir, gece eylemlerini engelleyebilir.'
      },
      vanished: {
        name: 'Kayıp',
        description: 'Oyun başına iki kez görünmez olabilir, bir gece boyunca tüm araştırma yeteneklerinden saklanabilir.'
      },
      blackmailer: {
        name: 'Şantajcı',
        description: 'Bir oyuncunun sonraki gün fazında oy kullanmasını veya konuşmasını engelleyebilir.'
      },
      detective: {
        name: 'Dedektif',
        description: 'Her gece bir oyuncuyu şüpheli faaliyetler açısından araştırabilir.'
      },
      seer: {
        name: 'Kahin',
        description: 'Her gece bir oyuncunun tam rolünü görebilir. Oyun başına üç kullanımla sınırlıdır.'
      },
      trapper: {
        name: 'Tuzakçı',
        description: 'Sabah fazında truva mesajı kullanarak tuzak kurabilir.'
      },
      veteran: {
        name: 'Veteran',
        description: 'Oyun başına üç kez alarma geçebilir, o gece kendisini ziyaret eden tüm oyuncuları öldürür.'
      },
      jailor: {
        name: 'Gardiyan',
        description: 'Gece bir oyuncuyu sorgulama ve infaz için gözaltına alabilir.'
      },
      classicSavior: {
        name: 'Klasik Kurtarıcı',
        description: 'Özel yetenekleri olmayan temel bir kasaba üyesi.'
      },
      vigilante: {
        name: 'Tetikçi',
        description: 'Oylama fazında bir oyuncuyu vurabilir. Bir müttefik Kurtarıcıyı öldürürse vicdan azabından ölür.'
      },
      doctor: {
        name: 'Doktor',
        description: 'Her gece bir oyuncuyu iyileştirebilir, ölümünü engelleyebilir.'
      },
      manipulator: {
        name: 'Manipülatör',
        description: 'Hedefinin oylanarak çıkarılmasını sağlamalıdır. Diğer oyuncuları kontrol edemez ama sosyal manipülasyon kullanabilir.'
      },
      werewolf: {
        name: 'Kurt Adam',
        description: 'Dolunay gecelerinde bir oyuncunun evinde katliam yapabilir, onu ve tüm ziyaretçilerini öldürür.'
      },
      arsonist: {
        name: 'Kundakçı',
        description: 'Oyuncuları benzinle ıslatabilir ve tüm ıslattığı oyuncuları bir anda yakabilir.'
      },
      plague: {
        name: 'Veba',
        description: 'Oyuncuları etkileşimde bulundukları diğer oyunculara bulaşan bir hastalıkla enfekte edebilir.'
      }
    }
  },
  az: {
    welcome: {
      title: 'SİNDİKAT',
      subtitle: 'Oyuna qoşulmaq üçün kod adınızı daxil edin',
      enterGame: 'Oyuna Daxil Ol',
      viewRoleGuide: 'Rol Bələdçisini Göstər',
      agreeToRules: 'Daxil olmaqla qaydaları qəbul edirsiniz',
      roleGuide: 'Rol Bələdçisi',
      enterCodename: 'Kod adınızı daxil edin'
    },
    lobby: {
      welcome: 'Xoş Gəlmisiniz',
      availableRooms: 'Mövcud Otaqlar',
      createRoom: 'Otaq Yarat',
      joinRoom: 'Otağa Qoşul',
      enterRoomCode: 'Otaq kodunu daxil edin',
      roomName: 'Otaq adını daxil edin',
      players: 'oyunçu',
      noRooms: 'Mövcud otaq yoxdur',
      createRoomPrompt: 'Oynamağa başlamaq üçün otaq yaradın!',
      alreadyJoined: 'Artıq Qoşulmusunuz',
      join: 'Qoşul',
      create: 'Yarat',
      cancel: 'Ləğv Et',
      copied: 'Kopyalandı!',
      copyCode: 'Kodu Kopyala'
    },
    categories: {
      syndicate: 'Sindikat',
      saviors: 'Xilaskarlar',
      neutral: 'Neytral'
    },
    roles: {
      bossSyndicate: {
        name: 'Sindikat Rəhbəri',
        description: 'Sindikatın lideri. Bütün Sindikat üzvlərini görə və hücumları koordinasiya edə bilər.'
      },
      lesserSyndicate: {
        name: 'Kiçik Sindikat',
        description: 'Sindikat üzvü. Gecə öldürmələri edə və digər Sindikat üzvləri ilə gizli əlaqə saxlaya bilər.'
      },
      classicSyndicate: {
        name: 'Klassik Sindikat',
        description: 'Gecə öldürmələri və Sindikat söhbəti xaricində xüsusi qabiliyyətləri olmayan əsas Sindikat üzvü.'
      },
      flash: {
        name: 'Flaş',
        description: 'Gecə bütün oyunçuları kor edə bilər, gecə hərəkətlərini əngəlləyə bilər.'
      },
      vanished: {
        name: 'Yoxa Çıxan',
        description: 'Oyun ərzində iki dəfə görünməz ola bilər, bir gecə ərzində bütün araşdırma qabiliyyətlərindən gizlənə bilər.'
      },
      blackmailer: {
        name: 'Şantajçı',
        description: 'Bir oyunçunun növbəti gün fazasında səs verməsini və ya danışmasını əngəlləyə bilər.'
      },
      detective: {
        name: 'Detektiv',
        description: 'Hər gecə bir oyunçunu şübhəli fəaliyyətlər baxımından araşdıra bilər.'
      },
      seer: {
        name: 'Görücü',
        description: 'Hər gecə bir oyunçunun tam rolunu görə bilər. Oyun ərzində üç istifadə ilə məhdudlaşır.'
      },
      trapper: {
        name: 'Tələçi',
        description: 'Səhər fazasında troya mesajı istifadə edərək tələ qura bilər.'
      },
      veteran: {
        name: 'Veteran',
        description: 'Oyun ərzində üç dəfə həyəcan siqnalı verə bilər, həmin gecə onu ziyarət edən bütün oyunçuları öldürür.'
      },
      jailor: {
        name: 'Həbsxanaçı',
        description: 'Gecə bir oyunçunu sorğu-sual və edam üçün həbs edə bilər.'
      },
      classicSavior: {
        name: 'Klassik Xilaskar',
        description: 'Xüsusi qabiliyyətləri olmayan əsas şəhər üzvü.'
      },
      vigilante: {
        name: 'Sayıq',
        description: 'Səsvermə fazasında bir oyunçunu vura bilər. Müttəfiq Xilaskarı öldürərsə vicdan əzabından ölür.'
      },
      doctor: {
        name: 'Həkim',
        description: 'Hər gecə bir oyunçunu sağalda bilər, ölümünün qarşısını ala bilər.'
      },
      manipulator: {
        name: 'Manipulyator',
        description: 'Hədəfinin səsvermə ilə çıxarılmasını təmin etməlidir. Digər oyunçuları idarə edə bilməz, lakin sosial manipulyasiya istifadə edə bilər.'
      },
      werewolf: {
        name: 'Canavar Adam',
        description: 'Bədirlənmiş gecələrdə bir oyunçunun evində qırğın törədə bilər, onu və bütün ziyarətçilərini öldürür.'
      },
      arsonist: {
        name: 'Yanğınsöndürən',
        description: 'Oyunçuları benzinlə islada və bütün islatdığı oyunçuları birdən yandıra bilər.'
      },
      plague: {
        name: 'Taun',
        description: 'Oyunçuları qarşılıqlı əlaqədə olduqları digər oyunçulara yoluxan xəstəliklə yoluxa bilər.'
      }
    }
  },
  ru: {
    welcome: {
      title: 'СИНДИКАТ',
      subtitle: 'Введите свой позывной, чтобы присоединиться к игре',
      enterGame: 'Войти в Игру',
      viewRoleGuide: 'Просмотр Руководства по Ролям',
      agreeToRules: 'Входя, вы соглашаетесь с правилами',
      roleGuide: 'Руководство по Ролям',
      enterCodename: 'Введите свой позывной'
    },
    lobby: {
      welcome: 'Добро пожаловать',
      availableRooms: 'Доступные Комнаты',
      createRoom: 'Создать Комнату',
      joinRoom: 'Присоединиться',
      enterRoomCode: 'Введите код комнаты',
      roomName: 'Введите название комнаты',
      players: 'игроков',
      noRooms: 'Нет доступных комнат',
      createRoomPrompt: 'Создайте комнату, чтобы начать игру!',
      alreadyJoined: 'Уже Присоединились',
      join: 'Присоединиться',
      create: 'Создать',
      cancel: 'Отмена',
      copied: 'Скопировано!',
      copyCode: 'Копировать Код'
    },
    categories: {
      syndicate: 'Синдикат',
      saviors: 'Спасители',
      neutral: 'Нейтральный'
    },
    roles: {
      bossSyndicate: {
        name: 'Босс Синдиката',
        description: 'Лидер Синдиката. Может видеть всех членов Синдиката и координировать атаки.'
      },
      lesserSyndicate: {
        name: 'Младший Синдикат',
        description: 'Член Синдиката. Может совершать ночные убийства и тайно общаться с другими членами Синдиката.'
      },
      classicSyndicate: {
        name: 'Классический Синдикат',
        description: 'Базовый член Синдиката без особых способностей, кроме ночных убийств и чата Синдиката.'
      },
      flash: {
        name: 'Вспышка',
        description: 'Может ослепить всех игроков ночью, предотвращая любые ночные действия.'
      },
      vanished: {
        name: 'Исчезнувший',
        description: 'Может стать невидимым дважды за игру, скрываясь от всех следственных способностей на одну ночь.'
      },
      blackmailer: {
        name: 'Шантажист',
        description: 'Может помешать одному игроку голосовать или говорить в следующей дневной фазе.'
      },
      detective: {
        name: 'Детектив',
        description: 'Может расследовать одного игрока каждую ночь на предмет подозрительной деятельности.'
      },
      seer: {
        name: 'Провидец',
        description: 'Может раскрыть точную роль одного игрока каждую ночь. Ограничено тремя использованиями за игру.'
      },
      trapper: {
        name: 'Ловушечник',
        description: 'Может установить ловушку во время утренней фазы, используя троянское сообщение.'
      },
      veteran: {
        name: 'Ветеран',
        description: 'Может быть начеку три раза за игру, убивая всех игроков, которые посещают его в эту ночь.'
      },
      jailor: {
        name: 'Тюремщик',
        description: 'Может задержать одного игрока ночью для допроса и казни.'
      },
      classicSavior: {
        name: 'Классический Спаситель',
        description: 'Базовый член города без особых способностей.'
      },
      vigilante: {
        name: 'Мститель',
        description: 'Может застрелить одного игрока во время фазы голосования. Умирает от чувства вины, если убивает союзного Спасителя.'
      },
      doctor: {
        name: 'Доктор',
        description: 'Может вылечить одного игрока каждую ночь, предотвращая его смерть.'
      },
      manipulator: {
        name: 'Манипулятор',
        description: 'Должен добиться изгнания своей цели голосованием. Не может контролировать других игроков, но может использовать социальную манипуляцию.'
      },
      werewolf: {
        name: 'Оборотень',
        description: 'Может устроить резню в доме одного игрока в ночи полнолуния, убивая его и всех посетителей.'
      },
      arsonist: {
        name: 'Поджигатель',
        description: 'Может облить игроков бензином и поджечь всех облитых игроков одновременно.'
      },
      plague: {
        name: 'Чума',
        description: 'Может заразить игроков болезнью, которая распространяется на игроков, с которыми они взаимодействуют.'
      }
    }
  }
};