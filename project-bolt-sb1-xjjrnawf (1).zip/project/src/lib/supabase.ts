import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

// Create a custom fetch function that includes the auth header
const customFetch = (url: string, options: RequestInit = {}) => {
  const headers = new Headers(options.headers);
  headers.set('Authorization', `Bearer ${supabaseAnonKey}`);
  
  return fetch(url, {
    ...options,
    headers,
  });
};

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true
  },
  global: {
    fetch: customFetch
  }
});

export const subscribeToRoom = (roomId: string, callback: (payload: any) => void) => {
  return supabase
    .channel(`room:${roomId}`)
    .on(
      'postgres_changes',
      {
        event: '*',
        schema: 'public',
        table: 'rooms',
        filter: `id=eq.${roomId}`
      },
      callback
    )
    .subscribe();
};

export const subscribeToPlayers = (roomId: string, callback: (payload: any) => void) => {
  return supabase
    .channel(`players:${roomId}`)
    .on(
      'postgres_changes',
      {
        event: '*',
        schema: 'public',
        table: 'players',
        filter: `room_id=eq.${roomId}`
      },
      (payload) => {
        console.log('Player Event:', payload); // Debug log
        callback(payload);
      }
    )
    .subscribe();
};

export const subscribeToGameEvents = (roomId: string, callback: (payload: any) => void) => {
  return supabase
    .channel(`events:${roomId}`)
    .on(
      'postgres_changes',
      {
        event: 'INSERT',
        schema: 'public',
        table: 'game_events',
        filter: `room_id=eq.${roomId}`
      },
      callback
    )
    .subscribe();
};

export const subscribeToChatMessages = (roomId: string, callback: (payload: any) => void) => {
  return supabase
    .channel(`chat:${roomId}`)
    .on(
      'postgres_changes',
      {
        event: 'INSERT',
        schema: 'public',
        table: 'chat_messages',
        filter: `room_id=eq.${roomId}`
      },
      callback
    )
    .subscribe();
};

export const updatePlayerActivity = async (username: string) => {
  try {
    const { error } = await supabase
      .from('players')
      .update({ last_active: new Date().toISOString() })
      .eq('username', username);

    if (error) {
      console.error('Error updating player activity:', error);
      throw error;
    }
  } catch (error) {
    console.error('Failed to update player activity:', error);
    throw error;
  }
};

export const getActivePlayers = async () => {
  try {
    const twoMinutesAgo = new Date(Date.now() - 120000).toISOString();
    const { data, error, count } = await supabase
      .from('players')
      .select('*', { count: 'exact' })
      .gt('last_active', twoMinutesAgo)
      .eq('room_id', 'MAINGAME');

    if (error) {
      console.error('Error fetching active players:', error);
      throw error;
    }

    return { data, count };
  } catch (error) {
    console.error('Failed to get active players:', error);
    throw error;
  }
};

export const cleanupInactivePlayers = async () => {
  try {
    const twoMinutesAgo = new Date(Date.now() - 120000).toISOString();
    
    // Get current host
    const { data: room } = await supabase
      .from('rooms')
      .select('host')
      .eq('id', 'MAINGAME')
      .single();

    if (!room) return;

    // Delete inactive players except host
    const { error: deleteError } = await supabase
      .from('players')
      .delete()
      .lt('last_active', twoMinutesAgo)
      .eq('room_id', 'MAINGAME')
      .neq('username', room.host);

    if (deleteError) {
      console.error('Error cleaning up inactive players:', deleteError);
      throw deleteError;
    }

    // Check if host is still active
    const { data: hostPlayer } = await supabase
      .from('players')
      .select('last_active')
      .eq('username', room.host)
      .single();

    // If host is inactive and there are other active players, transfer host role
    if (hostPlayer && new Date(hostPlayer.last_active) < new Date(twoMinutesAgo)) {
      const { data: activePlayers } = await supabase
        .from('players')
        .select('username')
        .gt('last_active', twoMinutesAgo)
        .eq('room_id', 'MAINGAME')
        .order('created_at', { ascending: true })
        .limit(1);

      if (activePlayers && activePlayers.length > 0) {
        await supabase
          .from('rooms')
          .update({ host: activePlayers[0].username })
          .eq('id', 'MAINGAME');
      }
    }
  } catch (error) {
    console.error('Failed to cleanup inactive players:', error);
    throw error;
  }
};