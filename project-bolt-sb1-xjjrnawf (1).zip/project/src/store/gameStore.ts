import { create } from 'zustand';
import { supabase } from '../lib/supabase';

type BaseRole = 'detective' | 'seer' | 'trapper' | 'veteran' | 'jailor' | 'classic-savior' | 
           'vigilante' | 'doctor' | 'politician' | 'swapper' | 'teleporter' | 'medium' | 
           'prosecutor' | 'survivor' | 'amnesiac' | 'guardian-angel' | 'manipulator' | 'jester' |
           'werewolf' | 'hacker' | 'arsonist' | 'plague' | 'pestilence';

type SyndicateRole = 'syndicate' | 'flash' | 'vanished' | 'blackmailer' | 'classic-syndicate';
type SyndicatePrefix = 'Boss' | 'Lesser';
type Role = BaseRole | `${SyndicatePrefix} ${SyndicateRole}`;

interface Kill {
  killer: string;
  victim: string;
  night: number;
  method: string;
}

interface Room {
  id: string;
  name: string;
  players: string[];
  alivePlayers: string[];
  maxPlayers: number;
  minPlayers: number;
  gameState: 'waiting' | 'playing' | 'countdown';
  phase: 'day' | 'night';
  currentRound: number;
  host: string;
  countdownTimer: number | null;
  playerRoles: Record<string, Role>;
  kills: Kill[];
  deadPlayerInfo: Record<string, {
    killer: string;
    night: number;
    method: string;
  }>;
  settings: {
    enabledRoles: Set<string>;
    confirmEjects: boolean;
    anonymousVoting: boolean;
  };
}

interface GameStore {
  username: string | null;
  rooms: Room[];
  subscriptions: Array<{ unsubscribe: () => void }>;
  activityInterval: number | null;
  playerCountInterval: number | null;
  activePlayerCount: number;
  addUsername: (username: string) => void;
  getUniqueUsername: (username: string) => Promise<string>;
  createRoom: (name: string) => Promise<string | null>;
  joinRoom: (roomId: string, username: string) => Promise<boolean>;
  leaveRoom: (roomId: string, username: string) => void;
  startGameCountdown: (roomId: string) => Promise<void>;
  cancelGameCountdown: (roomId: string) => Promise<void>;
  startGame: (roomId: string) => Promise<void>;
  updateRoomSettings: (roomId: string, settings: Partial<Room['settings']>) => Promise<void>;
  initializeRooms: () => Promise<void>;
  getPlayerRole: (roomId: string, viewer: string, target: string) => string | null;
  generateRoomLink: (roomId: string) => string;
  getRoomFromLink: (roomId: string) => Promise<Room | null>;
  cleanup: () => Promise<void>;
  subscribe: () => void;
  unsubscribe: () => void;
  startActivityTracking: () => void;
  stopActivityTracking: () => void;
  fetchActivePlayerCount: () => Promise<void>;
  fetchPlayers: () => Promise<void>;
}

const MAIN_ROOM_ID = 'MAINGAME';
const ACTIVITY_INTERVAL = 10000; // 10 seconds
const PLAYER_COUNT_INTERVAL = 15000; // 15 seconds

export const useGameStore = create<GameStore>((set, get) => {
  const cleanup = async () => {
    const username = get().username;
    if (username) {
      try {
        // Delete the player entry
        await supabase
          .from('players')
          .delete()
          .eq('username', username);
        
        // Get current room data
        const { data: room } = await supabase
          .from('rooms')
          .select('host')
          .eq('id', MAIN_ROOM_ID)
          .single();

        // If the leaving player was the host, assign host to the next player
        if (room && room.host === username) {
          const { data: remainingPlayers } = await supabase
            .from('players')
            .select('username')
            .eq('room_id', MAIN_ROOM_ID)
            .order('created_at', { ascending: true })
            .limit(1);

          if (remainingPlayers && remainingPlayers.length > 0) {
            await supabase
              .from('rooms')
              .update({ host: remainingPlayers[0].username })
              .eq('id', MAIN_ROOM_ID);
          } else {
            // If no players left, reset host to system
            await supabase
              .from('rooms')
              .update({ host: 'system' })
              .eq('id', MAIN_ROOM_ID);
          }
        }
        
        get().stopActivityTracking();
        get().unsubscribe();
        set({ username: null, rooms: [] });
      } catch (error) {
        console.error('Error cleaning up:', error);
      }
    }
  };

  if (typeof window !== 'undefined') {
    window.addEventListener('beforeunload', () => {
      cleanup();
    });
  }

  return {
    username: null,
    rooms: [],
    subscriptions: [],
    activityInterval: null,
    playerCountInterval: null,
    activePlayerCount: 0,

    fetchActivePlayerCount: async () => {
      try {
        const twoMinutesAgo = new Date(Date.now() - 120000).toISOString();
        const { data, error } = await supabase
          .from('players')
          .select('*', { count: 'exact' })
          .gt('last_active', twoMinutesAgo)
          .eq('room_id', MAIN_ROOM_ID);

        if (error) {
          console.error('Failed to fetch player count:', error);
          return;
        }

        set({ activePlayerCount: data.length });
      } catch (error) {
        console.error('Error fetching active player count:', error);
      }
    },

    fetchPlayers: async () => {
      try {
        const { data, error } = await supabase
          .from('players')
          .select('*')
          .eq('room_id', MAIN_ROOM_ID);

        if (error) {
          console.error('Error fetching players:', error);
          return;
        }

        const currentRooms = [...get().rooms];
        if (currentRooms.length > 0) {
          currentRooms[0].players = data.map(p => p.username);
          set({ rooms: currentRooms });
        }
      } catch (error) {
        console.error('Error in fetchPlayers:', error);
      }
    },

    startActivityTracking: () => {
      // Update player's last_active timestamp
      const activityInterval = window.setInterval(async () => {
        const username = get().username;
        if (username) {
          try {
            await supabase
              .from('players')
              .update({ last_active: new Date().toISOString() })
              .eq('username', username);
          } catch (error) {
            console.error('Error updating player activity:', error);
          }
        }
      }, ACTIVITY_INTERVAL);

      // Fetch active player count periodically
      const playerCountInterval = window.setInterval(() => {
        get().fetchActivePlayerCount();
      }, PLAYER_COUNT_INTERVAL);

      set({ activityInterval, playerCountInterval });
      get().fetchActivePlayerCount(); // Initial fetch
    },

    stopActivityTracking: () => {
      const activityInterval = get().activityInterval;
      const playerCountInterval = get().playerCountInterval;

      if (activityInterval) {
        clearInterval(activityInterval);
      }
      if (playerCountInterval) {
        clearInterval(playerCountInterval);
      }

      set({ 
        activityInterval: null,
        playerCountInterval: null
      });
    },

    subscribe: () => {
      console.log("Subscribing to players");
      
      // Remove all existing channels before creating new ones
      supabase.removeAllChannels();

      // Subscribe to ALL changes in the rooms table
      const roomSubscription = supabase
        .channel('room-changes')
        .on(
          'postgres_changes',
          { 
            event: '*', 
            schema: 'public', 
            table: 'rooms',
            filter: `id=eq.${MAIN_ROOM_ID}`
          },
          () => get().initializeRooms()
        )
        .subscribe();

      // Subscribe to ALL changes in the players table
      const playerSubscription = supabase
        .channel('player-changes')
        .on(
          'postgres_changes',
          { 
            event: '*', 
            schema: 'public', 
            table: 'players',
            filter: `room_id=eq.${MAIN_ROOM_ID}`
          },
          () => {
            get().initializeRooms();
            get().fetchActivePlayerCount();
            get().fetchPlayers();
          }
        )
        .subscribe();

      set(state => ({
        subscriptions: [
          ...state.subscriptions,
          { unsubscribe: () => roomSubscription.unsubscribe() },
          { unsubscribe: () => playerSubscription.unsubscribe() }
        ]
      }));
    },

    unsubscribe: () => {
      get().subscriptions.forEach(sub => sub.unsubscribe());
      supabase.removeAllChannels();
      set({ subscriptions: [] });
    },

    addUsername: (username: string) => set({ username }),

    getUniqueUsername: async (baseName: string) => {
      try {
        const { data: existingPlayers, error } = await supabase
          .from('players')
          .select('username');

        if (error) {
          console.error('Error checking usernames:', error);
          return baseName;
        }

        let finalName = baseName;
        let suffix = 1;
        const allNames = existingPlayers?.map(p => p.username) || [];

        while (allNames.includes(finalName)) {
          finalName = `${baseName}${suffix}`;
          suffix++;
        }

        return finalName;
      } catch (error) {
        console.error('Error in getUniqueUsername:', error);
        return baseName;
      }
    },

    createRoom: async (name: string) => {
      const username = get().username;
      if (!username) return null;

      try {
        const { data: existingRoom, error: roomError } = await supabase
          .from('rooms')
          .select('*')
          .eq('id', MAIN_ROOM_ID)
          .maybeSingle();

        if (roomError) {
          console.error('Error checking room:', roomError);
          return null;
        }

        if (!existingRoom) {
          const { data: roomData, error: createError } = await supabase
            .from('rooms')
            .insert({
              id: MAIN_ROOM_ID,
              name,
              host: username,
              game_state: 'waiting',
              settings: {
                enabledRoles: [
                  'classic-syndicate',
                  'flash',
                  'vanished',
                  'blackmailer',
                  'detective',
                  'seer',
                  'trapper',
                  'veteran',
                  'jailor',
                  'classic-savior',
                  'vigilante',
                  'doctor'
                ],
                confirmEjects: true,
                anonymousVoting: false
              }
            })
            .select()
            .single();

          if (createError || !roomData) {
            console.error('Error creating room:', createError);
            return null;
          }
        }

        const uniqueUsername = await get().getUniqueUsername(username);

        // Check if there are any existing players
        const { data: existingPlayers } = await supabase
          .from('players')
          .select('username')
          .eq('room_id', MAIN_ROOM_ID)
          .order('created_at', { ascending: true });

        const isFirstPlayer = !existingPlayers || existingPlayers.length === 0;

        // Add the new player
        const { error: insertError } = await supabase
          .from('players')
          .insert({
            room_id: MAIN_ROOM_ID,
            username: uniqueUsername,
            is_alive: true
          });

        if (insertError) {
          console.error('Error adding player:', insertError);
          return null;
        }

        // Update host only if this is the first player
        if (isFirstPlayer) {
          await supabase
            .from('rooms')
            .update({ host: uniqueUsername })
            .eq('id', MAIN_ROOM_ID);
        }

        set({ username: uniqueUsername });
        get().subscribe();
        get().startActivityTracking();
        await get().initializeRooms();
        return MAIN_ROOM_ID;
      } catch (error) {
        console.error('Error in createRoom:', error);
        return null;
      }
    },

    joinRoom: async (roomId: string, username: string) => {
      try {
        const uniqueUsername = await get().getUniqueUsername(username);

        // Check if there are any existing players
        const { data: existingPlayers } = await supabase
          .from('players')
          .select('username')
          .eq('room_id', roomId)
          .order('created_at', { ascending: true });

        const isFirstPlayer = !existingPlayers || existingPlayers.length === 0;

        // Add the new player
        const { error: insertError } = await supabase
          .from('players')
          .insert({
            room_id: roomId,
            username: uniqueUsername,
            is_alive: true
          });

        if (insertError) {
          console.error('Error joining room:', insertError);
          return false;
        }

        // Update host only if this is the first player
        if (isFirstPlayer) {
          await supabase
            .from('rooms')
            .update({ host: uniqueUsername })
            .eq('id', roomId);
        }

        // Cancel countdown if game is in countdown state
        const { data: room } = await supabase
          .from('rooms')
          .select('game_state')
          .eq('id', roomId)
          .single();

        if (room && room.game_state === 'countdown') {
          await get().cancelGameCountdown(roomId);
        }

        set({ username: uniqueUsername });
        get().subscribe();
        get().startActivityTracking();
        await get().initializeRooms();
        return true;
      } catch (error) {
        console.error('Error in joinRoom:', error);
        return false;
      }
    },

    leaveRoom: async (roomId: string, username: string) => {
      try {
        // Get current room data before deleting the player
        const { data: room } = await supabase
          .from('rooms')
          .select('host')
          .eq('id', roomId)
          .single();

        // Delete the player
        const { error } = await supabase
          .from('players')
          .delete()
          .eq('room_id', roomId)
          .eq('username', username);

        if (error) {
          console.error('Error leaving room:', error);
          return;
        }

        // If the leaving player was the host, assign host to the next player
        if (room && room.host === username) {
          const { data: remainingPlayers } = await supabase
            .from('players')
            .select('username')
            .eq('room_id', roomId)
            .order('created_at', { ascending: true })
            .limit(1);

          if (remainingPlayers && remainingPlayers.length > 0) {
            await supabase
              .from('rooms')
              .update({ host: remainingPlayers[0].username })
              .eq('id', roomId);
          } else {
            // If no players left, reset host to system
            await supabase
              .from('rooms')
              .update({ host: 'system' })
              .eq('id', roomId);
          }
        }

        get().stopActivityTracking();
        get().unsubscribe();
        await get().initializeRooms();
      } catch (error) {
        console.error('Error in leaveRoom:', error);
      }
    },

    startGameCountdown: async (roomId: string) => {
      try {
        const { error } = await supabase
          .from('rooms')
          .update({
            game_state: 'countdown',
            countdownTimer: 5
          })
          .eq('id', roomId);

        if (error) {
          console.error('Error starting game countdown:', error);
          return;
        }

        let countdown = 5;
        const timer = setInterval(async () => {
          countdown--;
          
          if (countdown <= 0) {
            clearInterval(timer);
            await get().startGame(roomId);
          } else {
            await supabase
              .from('rooms')
              .update({ countdownTimer: countdown })
              .eq('id', roomId);
          }
        }, 1000);
      } catch (error) {
        console.error('Error in startGameCountdown:', error);
      }
    },

    cancelGameCountdown: async (roomId: string) => {
      try {
        const { error } = await supabase
          .from('rooms')
          .update({
            game_state: 'waiting',
            countdownTimer: null
          })
          .eq('id', roomId);

        if (error) {
          console.error('Error canceling game countdown:', error);
        }
      } catch (error) {
        console.error('Error in cancelGameCountdown:', error);
      }
    },

    startGame: async (roomId: string) => {
      try {
        const { data: room } = await supabase
          .from('rooms')
          .select('*')
          .eq('id', roomId)
          .single();

        if (!room) return;

        const { data: players } = await supabase
          .from('players')
          .select('*')
          .eq('room_id', roomId);

        if (!players) return;

        const enabledRoles = room.settings.enabledRoles;
        const playerRoles: Record<string, Role> = {};

        const { error } = await supabase
          .from('rooms')
          .update({
            game_state: 'playing',
            phase: 'night',
            currentRound: 1,
            playerRoles
          })
          .eq('id', roomId);

        if (error) {
          console.error('Error starting game:', error);
        }
      } catch (error) {
        console.error('Error in startGame:', error);
      }
    },

    updateRoomSettings: async (roomId: string, settings: Partial<Room['settings']>) => {
      try {
        const { error } = await supabase
          .from('rooms')
          .update({
            settings: {
              ...get().rooms[0]?.settings,
              ...settings
            }
          })
          .eq('id', roomId);

        if (error) {
          console.error('Error updating room settings:', error);
        }
      } catch (error) {
        console.error('Error in updateRoomSettings:', error);
      }
    },

    initializeRooms: async () => {
      try {
        const { data: roomsData, error: roomsError } = await supabase
          .from('rooms')
          .select(`
            *,
            players (*)
          `)
          .eq('id', MAIN_ROOM_ID);

        if (roomsError) {
          console.error('Error fetching rooms:', roomsError);
          return;
        }

        if (roomsData[0] && roomsData[0].players.length > 0) {
          const currentHost = roomsData[0].host;
          const hostExists = roomsData[0].players.some((p: any) => p.username === currentHost);
          
          if (!hostExists && roomsData[0].players.length > 0) {
            // If host doesn't exist, assign the first player (by creation time) as host
            const { data: oldestPlayer } = await supabase
              .from('players')
              .select('username')
              .eq('room_id', MAIN_ROOM_ID)
              .order('created_at', { ascending: true })
              .limit(1)
              .single();

            if (oldestPlayer) {
              await supabase
                .from('rooms')
                .update({ host: oldestPlayer.username })
                .eq('id', MAIN_ROOM_ID);
              
              roomsData[0].host = oldestPlayer.username;
            }
          }
        }

        const formattedRooms = roomsData.map((room) => ({
          ...room,
          players: room.players.map((p: any) => p.username),
          maxPlayers: 15,
          minPlayers: 4
        }));

        set({ rooms: formattedRooms });
      } catch (error) {
        console.error('Error in initializeRooms:', error);
      }
    },

    getPlayerRole: (roomId: string, viewer: string, target: string) => {
      const room = get().rooms.find(r => r.id === roomId);
      if (!room || !room.playerRoles) return null;

      if (viewer === target || room.gameState !== 'playing') {
        return room.playerRoles[target] || null;
      }

      return null;
    },

    generateRoomLink: (roomId: string) => `${window.location.origin}/room/${roomId}`,
    
    getRoomFromLink: async (roomId: string) => {
      try {
        const { data, error } = await supabase
          .from('rooms')
          .select('*')
          .eq('id', roomId)
          .single();

        if (error || !data) {
          console.error('Error getting room from link:', error);
          return null;
        }

        return data as Room;
      } catch (error) {
        console.error('Error in getRoomFromLink:', error);
        return null;
      }
    },

    cleanup
  };
});

export default useGameStore;