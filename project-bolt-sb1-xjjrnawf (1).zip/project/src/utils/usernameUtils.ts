/**
 * Validates if a username meets the minimum length requirement
 */
export const isValidUsername = (username: string): boolean => {
  return username.trim().length >= 3;
};

/**
 * Saves the username to localStorage
 */
export const saveUsername = (username: string): void => {
  localStorage.setItem('mafiaGameUsername', username);
};

/**
 * Retrieves the username from localStorage
 */
export const getStoredUsername = (): string | null => {
  return localStorage.getItem('mafiaGameUsername');
};