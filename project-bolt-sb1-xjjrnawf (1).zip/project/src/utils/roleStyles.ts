export const getRoleStyles = (role: string | null) => {
  // Default styles for unknown roles
  let baseStyles = {
    button: 'bg-gray-700 hover:bg-gray-600',
    chat: 'bg-gray-800',
    text: 'text-white',
    border: 'border-gray-700'
  };

  // Syndicate roles
  if (role?.toLowerCase().includes('syndicate')) {
    baseStyles = {
      button: 'bg-red-900 hover:bg-red-800',
      chat: 'bg-red-900/20',
      text: 'text-red-100',
      border: 'border-red-800'
    };
  }
  // Flash
  else if (role?.toLowerCase() === 'flash') {
    baseStyles = {
      button: 'bg-yellow-700 hover:bg-yellow-600',
      chat: 'bg-yellow-900/20',
      text: 'text-yellow-100',
      border: 'border-yellow-800'
    };
  }
  // Vanished
  else if (role?.toLowerCase() === 'vanished') {
    baseStyles = {
      button: 'bg-purple-900 hover:bg-purple-800',
      chat: 'bg-purple-900/20',
      text: 'text-purple-100',
      border: 'border-purple-800'
    };
  }
  // Detective
  else if (role?.toLowerCase() === 'detective') {
    baseStyles = {
      button: 'bg-blue-900 hover:bg-blue-800',
      chat: 'bg-blue-900/20',
      text: 'text-blue-100',
      border: 'border-blue-800'
    };
  }
  // Seer
  else if (role?.toLowerCase() === 'seer') {
    baseStyles = {
      button: 'bg-indigo-900 hover:bg-indigo-800',
      chat: 'bg-indigo-900/20',
      text: 'text-indigo-100',
      border: 'border-indigo-800'
    };
  }
  // Trapper
  else if (role?.toLowerCase() === 'trapper') {
    baseStyles = {
      button: 'bg-green-900 hover:bg-green-800',
      chat: 'bg-green-900/20',
      text: 'text-green-100',
      border: 'border-green-800'
    };
  }
  // Jailor
  else if (role?.toLowerCase() === 'jailor') {
    baseStyles = {
      button: 'bg-amber-900 hover:bg-amber-800',
      chat: 'bg-amber-900/20',
      text: 'text-amber-100',
      border: 'border-amber-800'
    };
  }
  // Neutral Killers
  else if (['werewolf', 'arsonist', 'plague'].includes(role?.toLowerCase() ?? '')) {
    baseStyles = {
      button: 'bg-rose-900 hover:bg-rose-800',
      chat: 'bg-rose-900/20',
      text: 'text-rose-100',
      border: 'border-rose-800'
    };
  }

  return baseStyles;
};