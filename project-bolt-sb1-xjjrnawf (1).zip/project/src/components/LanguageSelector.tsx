import React from 'react';
import { Globe } from 'lucide-react';
import { useLanguageStore } from '../store/languageStore';

const languages = [
  { code: 'en', name: 'English' },
  { code: 'tr', name: 'Türkçe' },
  { code: 'az', name: 'Azərbaycan' },
  { code: 'ru', name: 'Русский' }
] as const;

const LanguageSelector: React.FC = () => {
  const { currentLanguage, setLanguage } = useLanguageStore();

  return (
    <div className="relative group">
      <button className="text-gray-400 hover:text-white transition-colors flex items-center gap-2">
        <Globe size={20} />
        <span>{languages.find(lang => lang.code === currentLanguage)?.name}</span>
      </button>
      
      <div className="absolute right-0 mt-2 py-2 w-48 bg-gray-800 rounded-lg shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
        {languages.map((lang) => (
          <button
            key={lang.code}
            onClick={() => setLanguage(lang.code)}
            className={`w-full px-4 py-2 text-left hover:bg-gray-700 transition-colors ${
              currentLanguage === lang.code ? 'text-white bg-gray-700' : 'text-gray-400'
            }`}
          >
            {lang.name}
          </button>
        ))}
      </div>
    </div>
  );
}

export default LanguageSelector;