import React from 'react';
import { UserX } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface KickButtonProps {
  currentUserId: string;
  roomId: string;
}

const KickButton: React.FC<KickButtonProps> = ({ currentUserId, roomId }) => {
  const handleKick = async () => {
    try {
      // Get current room data to check if user is host
      const { data: room } = await supabase
        .from('rooms')
        .select('host')
        .eq('id', roomId)
        .single();

      if (!room || room.host !== currentUserId) {
        alert('Only the host can kick players.');
        return;
      }

      // Get all players except the current user
      const { data: players, error: fetchError } = await supabase
        .from('players')
        .select('id, username')
        .eq('room_id', roomId)
        .neq('username', currentUserId);

      if (fetchError) {
        console.error('Failed to fetch players:', fetchError.message);
        return;
      }

      if (!players || players.length === 0) {
        alert('No other players to kick.');
        return;
      }

      const playerIds = players.map(p => p.id);

      // Delete all selected players
      const { error: deleteError } = await supabase
        .from('players')
        .delete()
        .in('id', playerIds);

      if (deleteError) {
        console.error('Failed to kick players:', deleteError.message);
        alert('Failed to kick players.');
      }
    } catch (error) {
      console.error('Error in kick operation:', error);
      alert('An error occurred while kicking players.');
    }
  };

  return (
    <button
      onClick={handleKick}
      className="bg-red-800 hover:bg-red-700 text-white px-4 py-2 rounded-lg transition-colors flex items-center gap-2"
      title="Kick all other players"
    >
      <UserX size={20} />
      <span>Kick All</span>
    </button>
  );
};

export default KickButton;