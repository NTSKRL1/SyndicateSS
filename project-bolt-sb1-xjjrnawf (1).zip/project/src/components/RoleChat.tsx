import React from 'react';
import { getRoleStyles } from '../utils/roleStyles';
import { Lock } from 'lucide-react';

interface RoleChatProps {
  role: string;
  messages: Array<{
    id: string;
    sender: string;
    content: string;
    timestamp: number;
  }>;
  onSendMessage: (content: string) => void;
  title: string;
  isSyndicateChat?: boolean;
}

const RoleChat: React.FC<RoleChatProps> = ({ role, messages, onSendMessage, title, isSyndicateChat }) => {
  const [message, setMessage] = React.useState('');
  const styles = getRoleStyles(role);
  const chatRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    if (chatRef.current) {
      chatRef.current.scrollTop = chatRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim()) {
      onSendMessage(message.trim());
      setMessage('');
    }
  };

  return (
    <div className={`${styles.chat} border ${styles.border} rounded-lg p-4 flex flex-col h-[400px]`}>
      <div className={`text-lg font-semibold mb-4 ${styles.text} flex items-center gap-2`}>
        {isSyndicateChat && <Lock size={16} />}
        {title}
      </div>
      
      <div 
        ref={chatRef}
        className="flex-1 overflow-y-auto space-y-2 mb-4"
      >
        {messages.map((msg) => (
          <div key={msg.id} className={`${styles.text} opacity-90`}>
            <span className="font-semibold">{msg.sender}:</span> {msg.content}
          </div>
        ))}
      </div>

      <form onSubmit={handleSubmit} className="flex gap-2">
        <input
          type="text"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          className="flex-1 bg-black/20 rounded px-3 py-2 text-white placeholder-gray-400 focus:outline-none"
          placeholder={isSyndicateChat ? "Send a secret message... 🤫" : "Type your message... 💭"}
        />
        <button
          type="submit"
          className={`${styles.button} px-4 py-2 rounded transition-colors ${styles.text}`}
        >
          Send
        </button>
      </form>
    </div>
  );
};

export default RoleChat;