import React, { useEffect, useState } from 'react';
import { Shield, Sword, Crown, Eye, Grape as Trap, Star, Sun as Gun, Syringe, Scale, Shuffle, HdmiPort as Portal, Ghost, Gavel, Heart, Brain, Skull, Flame, Brush as Virus } from 'lucide-react';

interface RoleRevealScreenProps {
  role: string;
  onComplete: () => void;
}

const RoleRevealScreen: React.FC<RoleRevealScreenProps> = ({ role, onComplete }) => {
  const [show, setShow] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShow(false);
      onComplete();
    }, 5000);

    return () => clearTimeout(timer);
  }, [onComplete]);

  const getRoleIcon = () => {
    switch (role.toLowerCase()) {
      // Syndicate roles
      case 'boss syndicate':
        return <Crown className="text-red-500" />;
      case 'lesser syndicate':
        return <Sword className="text-red-400" />;
      case 'flash':
        return <Star className="text-yellow-400" />;
      case 'vanished':
        return <Ghost className="text-purple-400" />;
      case 'blackmailer':
        return <Scale className="text-gray-400" />;
      
      // Savior roles
      case 'detective':
        return <Eye className="text-blue-400" />;
      case 'seer':
        return <Brain className="text-indigo-400" />;
      case 'trapper':
        return <Trap className="text-green-400" />;
      case 'veteran':
        return <Shield className="text-orange-400" />;
      case 'jailor':
        return <Gavel className="text-yellow-600" />;
      case 'classic-savior':
        return <Heart className="text-pink-400" />;
      case 'vigilante':
        return <Gun className="text-gray-400" />;
      case 'doctor':
        return <Syringe className="text-green-500" />;
      
      // Neutral roles
      case 'manipulator':
        return <Brain className="text-purple-500" />;
      case 'werewolf':
        return <Skull className="text-amber-500" />;
      case 'arsonist':
        return <Flame className="text-orange-500" />;
      case 'plague':
        return <Virus className="text-green-600" />;
      default:
        return <Star className="text-white" />;
    }
  };

  const getRoleColor = () => {
    if (role.includes('syndicate')) return 'from-red-900/50 to-red-700/30';
    if (['detective', 'seer', 'trapper', 'veteran', 'jailor', 'classic-savior', 'vigilante', 'doctor'].includes(role)) {
      return 'from-blue-900/50 to-blue-700/30';
    }
    return 'from-purple-900/50 to-purple-700/30';
  };

  if (!show) return null;

  return (
    <div className="fixed inset-0 bg-black/95 backdrop-blur-lg flex items-center justify-center z-50">
      <div className={`animate-fadeInUp p-12 rounded-2xl bg-gradient-to-b ${getRoleColor()} border border-gray-700`}>
        <div className="text-center">
          <div className="mb-6 transform scale-150">
            {getRoleIcon()}
          </div>
          <h2 className="text-4xl font-bold text-white mb-3">
            You are the {role.replace(/-/g, ' ')}
          </h2>
          <div className="w-32 h-1 bg-gradient-to-r from-transparent via-white/20 to-transparent mx-auto mb-4" />
          <p className="text-gray-400">
            The game will begin shortly...
          </p>
        </div>
      </div>
    </div>
  );
};

export default RoleRevealScreen;