import React from 'react';
import { Activity, Crown } from 'lucide-react';

interface PlayerListProps {
  players: string[];
  host: string;
  activePlayerCount: number;
}

const PlayerList: React.FC<PlayerListProps> = ({ players, host, activePlayerCount }) => {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-medium text-white">Players ({players.length}/15)</h3>
        <div className="flex items-center text-sm text-gray-400">
          <Activity size={16} className="text-green-500 mr-2" />
          {activePlayerCount} active
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {players.map((player) => (
          <div
            key={player}
            className={`p-4 rounded-lg ${
              player === host
                ? 'bg-red-900/20 border border-red-800'
                : 'bg-gray-700'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-white">{player}</span>
              {player === host && (
                <div className="flex items-center text-xs bg-red-800 text-white px-2 py-1 rounded">
                  <Crown size={12} className="mr-1" />
                  Host
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PlayerList;