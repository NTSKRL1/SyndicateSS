import React from 'react';
import { Settings, X } from 'lucide-react';

interface RoomSettingsProps {
  isOpen: boolean;
  onClose: () => void;
  settings: {
    enabledRoles: Set<string>;
    confirmEjects: boolean;
    anonymousVoting: boolean;
  };
  onSettingChange: (key: string, value: any) => void;
}

const RoomSettings: React.FC<RoomSettingsProps> = ({
  isOpen,
  onClose,
  settings,
  onSettingChange,
}) => {
  if (!isOpen) return null;

  const allRoles = {
    syndicate: ['classic-syndicate', 'flash', 'vanished', 'blackmailer'],
    saviors: [
      'detective',
      'seer',
      'trapper',
      'tracker',
      'stalker',
      'oracle',
      'sheriff',
      'medium',
      'prosecutor',
      'veteran',
      'jailor',
      'classic-savior',
      'vigilante',
      'doctor',
      'altruist',
      'swapper',
      'teleporter',
      'politician'
    ],
    neutral: [
      'manipulator',
      'amnesiac',
      'guardian-angel',
      'vampire',
      'survivor',
      'werewolf',
      'arsonist',
      'plague',
      'hacker'
    ],
  };

  const handleRoleToggle = (role: string) => {
    const newEnabledRoles = new Set(settings.enabledRoles);
    
    if (newEnabledRoles.has(role)) {
      // Check if we can disable this role
      const isSyndicate = allRoles.syndicate.includes(role);
      const isSavior = allRoles.saviors.includes(role);
      
      if (isSyndicate) {
        const remainingSyndicateRoles = Array.from(newEnabledRoles)
          .filter(r => allRoles.syndicate.includes(r))
          .length;
        if (remainingSyndicateRoles <= 1) return;
      }
      
      if (isSavior) {
        const remainingSaviorRoles = Array.from(newEnabledRoles)
          .filter(r => allRoles.saviors.includes(r))
          .length;
        if (remainingSaviorRoles <= 1) return;
      }
      
      newEnabledRoles.delete(role);
    } else {
      newEnabledRoles.add(role);
    }
    
    onSettingChange('enabledRoles', newEnabledRoles);
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center">
            <Settings className="text-red-500 mr-2" />
            <h2 className="text-xl font-bold text-white">Room Settings</h2>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <X size={24} />
          </button>
        </div>

        <div className="space-y-6">
          <div>
            <h3 className="text-lg font-medium text-white mb-4">Game Rules</h3>
            <div className="space-y-4">
              <label className="flex items-center justify-between p-3 bg-gray-800 rounded-lg">
                <span className="text-white">Confirm Ejects</span>
                <input
                  type="checkbox"
                  checked={settings.confirmEjects}
                  onChange={(e) => onSettingChange('confirmEjects', e.target.checked)}
                  className="w-5 h-5 rounded border-gray-600 text-red-600 focus:ring-red-500 bg-gray-700"
                />
              </label>
              
              <label className="flex items-center justify-between p-3 bg-gray-800 rounded-lg">
                <span className="text-white">Anonymous Voting</span>
                <input
                  type="checkbox"
                  checked={settings.anonymousVoting}
                  onChange={(e) => onSettingChange('anonymousVoting', e.target.checked)}
                  className="w-5 h-5 rounded border-gray-600 text-red-600 focus:ring-red-500 bg-gray-700"
                />
              </label>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-medium text-white mb-4">Enabled Roles</h3>
            
            {Object.entries(allRoles).map(([category, roles]) => (
              <div key={category} className="mb-6">
                <h4 className="text-red-500 capitalize mb-2">{category}</h4>
                <div className="grid grid-cols-2 gap-2">
                  {roles.map((role) => (
                    <label
                      key={role}
                      className="flex items-center justify-between p-2 bg-gray-800 rounded-lg"
                    >
                      <span className="text-white text-sm capitalize">
                        {role.replace(/-/g, ' ')}
                      </span>
                      <input
                        type="checkbox"
                        checked={settings.enabledRoles.has(role)}
                        onChange={() => handleRoleToggle(role)}
                        className="w-4 h-4 rounded border-gray-600 text-red-600 focus:ring-red-500 bg-gray-700"
                      />
                    </label>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default RoomSettings;