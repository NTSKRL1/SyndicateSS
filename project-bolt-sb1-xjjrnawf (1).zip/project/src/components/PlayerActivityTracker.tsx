import React, { useEffect } from 'react';
import { useGameStore } from '../store/gameStore';

interface PlayerActivityTrackerProps {
  username: string;
  roomId: string;
}

const PlayerActivityTracker: React.FC<PlayerActivityTrackerProps> = ({ username, roomId }) => {
  const { startActivityTracking, stopActivityTracking } = useGameStore();

  useEffect(() => {
    if (!username || !roomId) return;

    // Start tracking player activity
    startActivityTracking();

    // Cleanup on unmount
    return () => {
      stopActivityTracking();
    };
  }, [username, roomId, startActivityTracking, stopActivityTracking]);

  return null; // This is a utility component that doesn't render anything
};

export default PlayerActivityTracker;