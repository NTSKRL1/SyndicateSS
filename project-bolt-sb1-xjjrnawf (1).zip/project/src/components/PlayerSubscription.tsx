import React, { useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useGameStore } from '../store/gameStore';

interface PlayerSubscriptionProps {
  roomId: string;
  onPlayerUpdate: () => void;
}

const PlayerSubscription: React.FC<PlayerSubscriptionProps> = ({ roomId, onPlayerUpdate }) => {
  useEffect(() => {
    if (!roomId) return;

    const channel = supabase
      .channel(`room-${roomId}`)
      .on(
        "postgres_changes",
        {
          event: "*",  // Handles all events: INSERT, UPDATE, DELETE
          schema: "public",
          table: "players",
          filter: `room_id=eq.${roomId}`,  // Only listen for this room
        },
        (payload) => {
          console.log("Player Event:", payload); // Debugging: Log event payload
          onPlayerUpdate();
        }
      )
      .subscribe();

    // Cleanup when component unmounts or room changes
    return () => {
      supabase.removeChannel(channel);
    };
  }, [roomId, onPlayerUpdate]);

  return null; // This component doesn't render anything
};

export default PlayerSubscription;