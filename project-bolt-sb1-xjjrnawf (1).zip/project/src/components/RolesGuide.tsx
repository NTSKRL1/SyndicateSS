import React, { useState } from 'react';
import { Shield, Sword, Crown, Eye, Grape as Trap, Star, Sun as Gun, Syringe, Scale, Ghost, Gavel, Heart, Brain, Skull, Flame, Brush as Virus, X } from 'lucide-react';
import { useLanguageStore } from '../store/languageStore';
import { translations } from '../translations';

interface RolesGuideProps {
  isOpen: boolean;
  onClose: () => void;
}

const RolesGuide: React.FC<RolesGuideProps> = ({ isOpen, onClose }) => {
  const [selectedCategory, setSelectedCategory] = useState<'syndicate' | 'saviors' | 'neutral'>('syndicate');
  const { currentLanguage } = useLanguageStore();
  const t = translations[currentLanguage];

  if (!isOpen) return null;

  const roleCategories = {
    syndicate: [
      {
        key: 'bossSyndicate',
        icon: <Crown className="text-red-500" />,
        color: 'from-red-900/50 to-red-700/30'
      },
      {
        key: 'lesserSyndicate',
        icon: <Sword className="text-red-400" />,
        color: 'from-red-900/50 to-red-700/30'
      },
      {
        key: 'classicSyndicate',
        icon: <Sword className="text-red-400" />,
        color: 'from-red-900/50 to-red-700/30'
      },
      {
        key: 'flash',
        icon: <Star className="text-yellow-400" />,
        color: 'from-red-900/50 to-red-700/30'
      },
      {
        key: 'vanished',
        icon: <Ghost className="text-purple-400" />,
        color: 'from-red-900/50 to-red-700/30'
      },
      {
        key: 'blackmailer',
        icon: <Scale className="text-gray-400" />,
        color: 'from-red-900/50 to-red-700/30'
      }
    ],
    saviors: [
      {
        key: 'detective',
        icon: <Eye className="text-blue-400" />,
        color: 'from-blue-900/50 to-blue-700/30'
      },
      {
        key: 'seer',
        icon: <Brain className="text-indigo-400" />,
        color: 'from-blue-900/50 to-blue-700/30'
      },
      {
        key: 'trapper',
        icon: <Trap className="text-green-400" />,
        color: 'from-blue-900/50 to-blue-700/30'
      },
      {
        key: 'veteran',
        icon: <Shield className="text-orange-400" />,
        color: 'from-blue-900/50 to-blue-700/30'
      },
      {
        key: 'jailor',
        icon: <Gavel className="text-yellow-600" />,
        color: 'from-blue-900/50 to-blue-700/30'
      },
      {
        key: 'classicSavior',
        icon: <Heart className="text-pink-400" />,
        color: 'from-blue-900/50 to-blue-700/30'
      },
      {
        key: 'vigilante',
        icon: <Gun className="text-gray-400" />,
        color: 'from-blue-900/50 to-blue-700/30'
      },
      {
        key: 'doctor',
        icon: <Syringe className="text-green-500" />,
        color: 'from-blue-900/50 to-blue-700/30'
      }
    ],
    neutral: [
      {
        key: 'manipulator',
        icon: <Brain className="text-purple-500" />,
        color: 'from-purple-900/50 to-purple-700/30'
      },
      {
        key: 'werewolf',
        icon: <Skull className="text-amber-500" />,
        color: 'from-purple-900/50 to-purple-700/30'
      },
      {
        key: 'arsonist',
        icon: <Flame className="text-orange-500" />,
        color: 'from-purple-900/50 to-purple-700/30'
      },
      {
        key: 'plague',
        icon: <Virus className="text-green-600" />,
        color: 'from-purple-900/50 to-purple-700/30'
      }
    ]
  };

  return (
    <div className="fixed inset-0 bg-black/90 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-gray-900 border border-gray-800 rounded-xl p-8 max-w-4xl w-full mx-4 max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-white">{t.welcome.roleGuide}</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <X size={24} />
          </button>
        </div>

        <div className="flex gap-4 mb-6">
          {(['syndicate', 'saviors', 'neutral'] as const).map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 py-2 rounded-lg font-medium transition-all ${
                selectedCategory === category
                  ? 'bg-red-800 text-white'
                  : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
              }`}
            >
              {t.categories[category]}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {roleCategories[selectedCategory].map((role) => (
            <div
              key={role.key}
              className={`p-6 rounded-xl bg-gradient-to-b ${role.color} border border-gray-800 transition-transform hover:scale-[1.02]`}
            >
              <div className="flex items-center gap-3 mb-3">
                <div className="w-8 h-8 flex items-center justify-center">
                  {role.icon}
                </div>
                <h3 className="text-xl font-bold text-white">
                  {t.roles[role.key].name}
                </h3>
              </div>
              <p className="text-gray-300">
                {t.roles[role.key].description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default RolesGuide;