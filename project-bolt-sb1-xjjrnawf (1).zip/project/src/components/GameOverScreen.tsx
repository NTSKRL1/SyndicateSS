import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Trophy, Users, ArrowLeft, Skull } from 'lucide-react';

interface GameOverScreenProps {
  winner: 'syndicate' | 'saviors' | 'neutral';
  players: Array<{
    username: string;
    role: string;
    isAlive: boolean;
  }>;
  kills: Array<{
    killer: string;
    victim: string;
    night: number;
    method: string;
  }>;
  onReset: () => void;
}

const GameOverScreen: React.FC<GameOverScreenProps> = ({ winner, players, kills, onReset }) => {
  const navigate = useNavigate();

  const handleReturnToLobby = () => {
    onReset();
    navigate('/lobby');
  };

  return (
    <div className="fixed inset-0 bg-black/90 backdrop-blur-sm flex items-center justify-center z-50 animate-fadeIn">
      <div className="bg-gray-900 border border-gray-800 rounded-xl p-8 max-w-4xl w-full mx-4 max-h-[90vh] overflow-y-auto">
        <div className="text-center mb-8">
          <Trophy className="w-16 h-16 mx-auto mb-4 text-yellow-500" />
          <h2 className="text-3xl font-bold text-white mb-2">
            {winner === 'syndicate' && 'Syndicate Wins!'}
            {winner === 'saviors' && 'Saviors Win!'}
            {winner === 'neutral' && 'Neutral Victory!'}
          </h2>
          <p className="text-gray-400">The game has ended</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
          <div>
            <div className="flex items-center mb-4">
              <Users className="text-red-500 mr-2" />
              <h3 className="text-lg font-medium text-white">Players & Roles</h3>
            </div>
            <div className="space-y-2">
              {players.map((player) => (
                <div
                  key={player.username}
                  className={`p-3 rounded-lg bg-gray-800 flex items-center justify-between ${
                    !player.isAlive ? 'opacity-50' : ''
                  }`}
                >
                  <div>
                    <span className="text-white font-medium">{player.username}</span>
                    <span className="text-sm text-gray-400 ml-2">({player.role})</span>
                  </div>
                  {!player.isAlive && (
                    <span className="text-xs bg-gray-700 px-2 py-1 rounded">Dead</span>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div>
            <div className="flex items-center mb-4">
              <Skull className="text-red-500 mr-2" />
              <h3 className="text-lg font-medium text-white">Kill Log</h3>
            </div>
            <div className="space-y-2">
              {kills.map((kill, index) => (
                <div key={index} className="p-3 rounded-lg bg-gray-800">
                  <div className="text-white">
                    <span className="font-medium">{kill.killer}</span>
                    <span className="text-gray-400"> killed </span>
                    <span className="font-medium">{kill.victim}</span>
                  </div>
                  <div className="text-sm text-gray-400">
                    Night {kill.night} • {kill.method}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <button
          onClick={handleReturnToLobby}
          className="w-full bg-red-800 hover:bg-red-700 text-white py-3 px-6 rounded-lg font-medium transition-all duration-300 flex items-center justify-center"
        >
          <ArrowLeft className="mr-2" />
          Return to Lobby
        </button>
      </div>
    </div>
  );
}

export default GameOverScreen;