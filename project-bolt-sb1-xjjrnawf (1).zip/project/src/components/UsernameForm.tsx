import React, { useState } from 'react';
import { UserCircle } from 'lucide-react';
import { useLanguageStore } from '../store/languageStore';
import { translations } from '../translations';
import { isValidUsername } from '../utils/usernameUtils';

interface UsernameFormProps {
  onSubmit: (username: string) => void;
}

const UsernameForm: React.FC<UsernameFormProps> = ({ onSubmit }) => {
  const [username, setUsername] = useState('');
  const [error, setError] = useState('');
  const [isFocused, setIsFocused] = useState(false);
  const { currentLanguage } = useLanguageStore();
  const t = translations[currentLanguage];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!isValidUsername(username)) {
      setError('Username must be at least 3 characters');
      return;
    }
    
    onSubmit(username);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setUsername(e.target.value);
    if (error && isValidUsername(e.target.value)) {
      setError('');
    }
  };

  return (
    <form 
      onSubmit={handleSubmit} 
      className="w-full max-w-md mx-auto"
    >
      <div className="relative mb-6">
        <div className={`absolute left-3 top-1/2 transform -translate-y-1/2 transition-all duration-300 ${isFocused || username ? 'text-red-500' : 'text-gray-400'}`}>
          <UserCircle size={24} />
        </div>
        <input
          type="text"
          value={username}
          onChange={handleChange}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          placeholder={t.welcome.enterCodename}
          className={`w-full pl-12 pr-4 py-3 bg-gray-800 border-2 ${error ? 'border-red-500' : isFocused ? 'border-red-500' : 'border-gray-700'} rounded-lg text-white placeholder-gray-500 focus:outline-none transition-colors duration-300`}
          autoFocus
        />
        {error && (
          <p className="text-red-500 text-sm mt-1 ml-1 absolute">{error}</p>
        )}
      </div>
      <button 
        type="submit"
        className="w-full bg-red-800 hover:bg-red-700 active:bg-red-900 text-white py-3 px-6 rounded-lg font-medium transition-all duration-300 transform hover:scale-[1.02] active:scale-[0.98] mt-4"
      >
        {t.welcome.enterGame}
      </button>
    </form>
  );
};

export default UsernameForm