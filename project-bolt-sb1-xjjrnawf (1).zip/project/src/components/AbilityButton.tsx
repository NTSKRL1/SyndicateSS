import React from 'react';
import { getRoleStyles } from '../utils/roleStyles';

interface AbilityButtonProps {
  role: string;
  onClick: () => void;
  disabled?: boolean;
  children: React.ReactNode;
}

const AbilityButton: React.FC<AbilityButtonProps> = ({ role, onClick, disabled = false, children }) => {
  const styles = getRoleStyles(role);

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`${styles.button} ${disabled ? 'opacity-50 cursor-not-allowed' : ''} 
        px-4 py-2 rounded-lg transition-all duration-200 transform hover:scale-[1.02] active:scale-[0.98]
        flex items-center gap-2 ${styles.text}`}
    >
      {children}
    </button>
  );
};

export default AbilityButton;