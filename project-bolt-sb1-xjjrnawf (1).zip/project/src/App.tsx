import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import WelcomeScreen from './screens/WelcomeScreen';
import RoomScreen from './screens/RoomScreen';
import { getStoredUsername } from './utils/usernameUtils';

function App() {
  // Protected route component that checks for username
  const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
    const username = getStoredUsername();
    if (!username) {
      return <Navigate to="/" replace />;
    }
    return <>{children}</>;
  };

  return (
    <Router>
      <Routes>
        <Route path="/" element={<WelcomeScreen />} />
        <Route 
          path="/room" 
          element={
            <ProtectedRoute>
              <RoomScreen />
            </ProtectedRoute>
          } 
        />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
}

export default App;