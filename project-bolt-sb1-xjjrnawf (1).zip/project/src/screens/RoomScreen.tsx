import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Play, Timer, Settings as SettingsIcon } from 'lucide-react';
import { useGameStore } from '../store/gameStore';
import RoomSettings from '../components/RoomSettings';
import RoleRevealScreen from '../components/RoleRevealScreen';
import PlayerList from '../components/PlayerList';
import PlayerActivityTracker from '../components/PlayerActivityTracker';
import PlayerSubscription from '../components/PlayerSubscription';
import KickButton from '../components/KickButton';

const RoomScreen: React.FC = () => {
  const navigate = useNavigate();
  const { 
    rooms, 
    username, 
    startGameCountdown, 
    updateRoomSettings, 
    getPlayerRole, 
    leaveRoom, 
    cleanup,
    activePlayerCount,
    fetchPlayers 
  } = useGameStore();
  const [showSettings, setShowSettings] = useState(false);
  const [showRoleReveal, setShowRoleReveal] = useState(false);
  
  const room = rooms[0];

  useEffect(() => {
    if (!username) {
      navigate('/');
    }
  }, [username, navigate]);

  const playerRole = room && username ? getPlayerRole(room.id, username, username) : null;

  useEffect(() => {
    if (room?.gameState === 'playing' && playerRole) {
      setShowRoleReveal(true);
    }
  }, [room?.gameState, playerRole]);

  const handleLeaveRoom = async () => {
    if (room?.id && username) {
      await leaveRoom(room.id, username);
      await cleanup();
      localStorage.removeItem('mafiaGameUsername');
      navigate('/');
    }
  };

  if (!room || !username) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-white mb-4">Loading game...</h2>
          <button
            onClick={() => navigate('/')}
            className="bg-red-800 hover:bg-red-700 text-white px-6 py-2 rounded-lg transition-colors flex items-center"
          >
            <ArrowLeft className="mr-2" />
            Return to Welcome Screen
          </button>
        </div>
      </div>
    );
  }

  const isHost = room.host === username;
  const canStartGame = isHost && room.players.length >= room.minPlayers && room.gameState === 'waiting';

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-gray-800">
      <PlayerActivityTracker username={username} roomId={room.id} />
      <PlayerSubscription roomId={room.id} onPlayerUpdate={fetchPlayers} />
      
      {showRoleReveal && playerRole && (
        <RoleRevealScreen
          role={playerRole}
          onComplete={() => setShowRoleReveal(false)}
        />
      )}

      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-white">{room.name}</h1>
          <div className="flex items-center gap-4">
            {isHost && room.gameState === 'waiting' && (
              <>
                <KickButton currentUserId={username} roomId={room.id} />
                <button
                  onClick={() => setShowSettings(true)}
                  className="bg-gray-800 hover:bg-gray-700 text-white px-4 py-2 rounded-lg transition-colors flex items-center"
                >
                  <SettingsIcon className="mr-2" />
                  Settings
                </button>
              </>
            )}
            <button
              onClick={handleLeaveRoom}
              className="bg-gray-800 hover:bg-gray-700 text-white px-4 py-2 rounded-lg transition-colors flex items-center"
            >
              <ArrowLeft className="mr-2" />
              Leave Game
            </button>
          </div>
        </div>

        <div className="bg-gray-800 rounded-lg p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            {canStartGame && (
              <button
                onClick={() => startGameCountdown(room.id)}
                className="bg-red-800 hover:bg-red-700 text-white px-6 py-2 rounded-lg transition-colors flex items-center"
              >
                <Play className="mr-2" />
                Start Game
              </button>
            )}
          </div>

          {room.gameState === 'countdown' && (
            <div className="text-center mb-4 animate-pulse">
              <div className="flex items-center justify-center text-2xl text-red-500">
                <Timer className="mr-2" />
                <span>Game starting in {room.countdownTimer}</span>
              </div>
            </div>
          )}

          <PlayerList 
            players={room.players} 
            host={room.host} 
            activePlayerCount={activePlayerCount}
          />
        </div>

        {room.gameState === 'waiting' && room.players.length < room.minPlayers && (
          <div className="text-center text-gray-400">
            <p>Waiting for more players to join...</p>
            <p className="text-sm">At least {room.minPlayers} players are needed to start the game</p>
          </div>
        )}

        <RoomSettings
          isOpen={showSettings}
          onClose={() => setShowSettings(false)}
          settings={room.settings}
          onSettingChange={handleSettingChange}
        />
      </div>
    </div>
  );
};

export default RoomScreen;