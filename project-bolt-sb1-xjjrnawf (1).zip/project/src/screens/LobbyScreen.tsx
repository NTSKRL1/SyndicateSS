import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Users, LogOut, Plus, Crown, Copy, Check, Link, Hash, Activity } from 'lucide-react';
import { useGameStore } from '../store/gameStore';
import { useLanguageStore } from '../store/languageStore';
import { translations } from '../translations';
import { getStoredUsername } from '../utils/usernameUtils';

const LobbyScreen: React.FC = () => {
  const navigate = useNavigate();
  const { 
    rooms, 
    createRoom, 
    joinRoom, 
    generateRoomLink, 
    username, 
    initializeRooms,
    activePlayerCount 
  } = useGameStore();
  const { currentLanguage } = useLanguageStore();
  const [isCreatingRoom, setIsCreatingRoom] = useState(false);
  const [newRoomName, setNewRoomName] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [copiedRoomId, setCopiedRoomId] = useState<string | null>(null);
  const [joinCode, setJoinCode] = useState('');
  const [showCodeTooltip, setShowCodeTooltip] = useState<string | null>(null);
  const [createdRoomId, setCreatedRoomId] = useState<string | null>(null);
  
  const t = translations[currentLanguage];

  useEffect(() => {
    const storedUsername = getStoredUsername();
    if (!storedUsername) {
      navigate('/');
      return;
    }
    initializeRooms();
  }, [navigate, initializeRooms]);

  const handleLogout = () => {
    localStorage.removeItem('mafiaGameUsername');
    navigate('/');
  };

  const handleCreateRoom = async () => {
    if (!newRoomName.trim()) return;
    
    const roomId = await createRoom(newRoomName.trim());
    if (!roomId) {
      setError('Failed to create room');
      setTimeout(() => setError(null), 3000);
      return;
    }
    setCreatedRoomId(roomId);
  };

  const handleJoinRoom = async (roomId: string) => {
    if (!username) return;

    const room = rooms.find(r => r.id === roomId);
    if (!room) {
      setError('Room not found');
      return;
    }

    if (room.players.includes(username)) {
      navigate(`/room/${roomId}`);
      return;
    }

    const joined = await joinRoom(roomId, username);
    if (joined) {
      navigate(`/room/${roomId}`);
    } else {
      setError('Unable to join room');
      setTimeout(() => setError(null), 3000);
    }
  };

  const handleJoinByCode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!joinCode.trim()) return;
    await handleJoinRoom(joinCode.trim().toUpperCase());
  };

  const copyRoomCode = async (roomId: string) => {
    await navigator.clipboard.writeText(roomId);
    setCopiedRoomId(roomId);
    setTimeout(() => setCopiedRoomId(null), 2000);
  };

  const showRoomCode = (roomId: string) => {
    setShowCodeTooltip(roomId);
    setTimeout(() => setShowCodeTooltip(null), 2000);
  };

  if (!username) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-gray-900">
        <div className="animate-spin w-12 h-12 border-4 border-red-600 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-gray-800 flex flex-col">
      <header className="bg-gray-900 border-b border-gray-800 p-4">
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex items-center">
            <h1 className="font-serif text-2xl font-bold text-white">{t.welcome.title}</h1>
            <div className="ml-4 flex items-center bg-gray-800 px-3 py-1 rounded-full">
              <Activity size={16} className="text-green-500 mr-2" />
              <span className="text-sm text-gray-300">{activePlayerCount} active</span>
            </div>
          </div>
          <div className="flex items-center">
            <span className="text-white mr-4">{t.lobby.welcome}, {username}</span>
            <button 
              onClick={handleLogout}
              className="bg-gray-800 hover:bg-gray-700 p-2 rounded-full transition-colors"
            >
              <LogOut size={20} className="text-red-500" />
            </button>
          </div>
        </div>
      </header>
      
      <main className="flex-1 container mx-auto p-4">
        {error && (
          <div className="mb-4 p-4 bg-red-900/50 border border-red-700 rounded-lg text-white animate-fadeIn">
            {error}
          </div>
        )}

        <div className="mb-6 flex flex-wrap gap-4 items-center justify-between">
          <h2 className="text-xl font-medium text-white flex items-center">
            <Crown className="text-red-500 mr-2" />
            {t.lobby.availableRooms}
          </h2>
          <div className="flex gap-4">
            <form onSubmit={handleJoinByCode} className="flex gap-2">
              <div className="relative">
                <Hash size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  value={joinCode}
                  onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                  placeholder={t.lobby.enterRoomCode}
                  className="bg-gray-800 border border-gray-700 rounded-lg pl-10 pr-4 py-2 text-white focus:outline-none focus:border-red-500 w-48 uppercase"
                  maxLength={6}
                />
              </div>
              <button
                type="submit"
                className="bg-red-800 hover:bg-red-700 text-white px-4 py-2 rounded-lg flex items-center transition-colors"
              >
                <Link size={20} className="mr-2" />
                {t.lobby.joinRoom}
              </button>
            </form>
            <button
              onClick={() => setIsCreatingRoom(true)}
              className="bg-red-800 hover:bg-red-700 text-white px-4 py-2 rounded-lg flex items-center transition-colors"
            >
              <Plus size={20} className="mr-2" />
              {t.lobby.createRoom}
            </button>
          </div>
        </div>

        {isCreatingRoom && (
          <div className="mb-6 bg-gray-800 p-4 rounded-lg animate-fadeIn">
            <div className="flex gap-4">
              <input
                type="text"
                value={newRoomName}
                onChange={(e) => setNewRoomName(e.target.value)}
                placeholder={t.lobby.roomName}
                className="flex-1 bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-red-500"
              />
              <button
                onClick={handleCreateRoom}
                className="bg-red-800 hover:bg-red-700 text-white px-6 py-2 rounded-lg transition-colors"
              >
                {t.lobby.create}
              </button>
              <button
                onClick={() => {
                  setIsCreatingRoom(false);
                  setCreatedRoomId(null);
                }}
                className="bg-gray-700 hover:bg-gray-600 text-white px-6 py-2 rounded-lg transition-colors"
              >
                {t.lobby.cancel}
              </button>
            </div>
            {createdRoomId && (
              <div className="mt-4 p-4 bg-gray-700 rounded-lg flex items-center justify-between">
                <div className="flex items-center">
                  <Hash size={16} className="text-gray-400 mr-2" />
                  <span className="text-white font-mono text-lg tracking-wider">{createdRoomId}</span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleJoinRoom(createdRoomId)}
                    className="bg-red-800 hover:bg-red-700 text-white px-4 py-2 rounded-lg transition-colors flex items-center gap-2"
                  >
                    <Link size={16} />
                    <span>{t.lobby.joinRoom}</span>
                  </button>
                  <button
                    onClick={() => copyRoomCode(createdRoomId)}
                    className="bg-gray-600 hover:bg-gray-500 text-white px-3 py-2 rounded transition-colors flex items-center gap-2"
                  >
                    {copiedRoomId === createdRoomId ? (
                      <>
                        <Check size={16} className="text-green-500" />
                        <span>{t.lobby.copied}</span>
                      </>
                    ) : (
                      <>
                        <Copy size={16} />
                        <span>{t.lobby.copyCode}</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {rooms.length > 0 ? (
            rooms.map((room) => (
              <div
                key={room.id}
                className="bg-gray-800 rounded-lg p-6 hover:bg-gray-750 transition-colors"
              >
                <div className="flex justify-between items-start mb-4">
                  <h3 className="text-lg font-medium text-white">{room.name}</h3>
                  <div className="flex items-center gap-2">
                    <span className="bg-gray-700 px-2 py-1 rounded text-sm">
                      {room.players.length}/{room.maxPlayers}
                    </span>
                    <div className="relative">
                      <button
                        onClick={() => showRoomCode(room.id)}
                        className="bg-gray-700 hover:bg-gray-600 text-white px-3 py-1 rounded transition-colors flex items-center gap-2"
                      >
                        <Hash size={16} />
                        <span className="font-mono">{room.id}</span>
                      </button>
                    </div>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center text-gray-400">
                    <Users size={16} className="mr-2" />
                    <span>{room.players.length} {t.lobby.players}</span>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => copyRoomCode(room.id)}
                      className="bg-gray-700 hover:bg-gray-600 text-white px-3 py-2 rounded transition-colors relative"
                      title={t.lobby.copyCode}
                    >
                      {copiedRoomId === room.id ? (
                        <Check size={16} className="text-green-500" />
                      ) : (
                        <Copy size={16} />
                      )}
                    </button>
                    <button
                      onClick={() => handleJoinRoom(room.id)}
                      disabled={room.players.length >= room.maxPlayers}
                      className={`${
                        room.players.includes(username)
                          ? 'bg-gray-700'
                          : 'bg-red-800 hover:bg-red-700'
                      } disabled:bg-gray-700 disabled:cursor-not-allowed text-white px-4 py-2 rounded transition-colors`}
                    >
                      {room.players.includes(username) ? t.lobby.alreadyJoined : t.lobby.join}
                    </button>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="col-span-full text-center py-12 text-gray-400">
              <Users size={48} className="mx-auto mb-4 text-gray-500" />
              <p className="text-lg mb-2">{t.lobby.noRooms}</p>
              <p className="text-sm">{t.lobby.createRoomPrompt}</p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default LobbyScreen;