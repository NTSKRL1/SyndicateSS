import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Target, Book, Users, Activity } from 'lucide-react';
import UsernameForm from '../components/UsernameForm';
import RolesGuide from '../components/RolesGuide';
import LanguageSelector from '../components/LanguageSelector';
import { useGameStore } from '../store/gameStore';
import { useLanguageStore } from '../store/languageStore';
import { translations } from '../translations';
import { saveUsername } from '../utils/usernameUtils';

const WelcomeScreen: React.FC = () => {
  const navigate = useNavigate();
  const { getUniqueUsername, addUsername, createRoom, activePlayerCount, fetchActivePlayerCount } = useGameStore();
  const { currentLanguage } = useLanguageStore();
  const [showRolesGuide, setShowRolesGuide] = useState(false);
  
  const t = translations[currentLanguage];

  useEffect(() => {
    // Fetch initial player count
    fetchActivePlayerCount();
  }, [fetchActivePlayerCount]);

  const handleUsernameSubmit = async (submittedUsername: string) => {
    const uniqueUsername = await getUniqueUsername(submittedUsername.trim());
    saveUsername(uniqueUsername);
    addUsername(uniqueUsername);
    
    const roomId = await createRoom('Game Room');
    if (roomId) {
      navigate('/room');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-gray-800 flex flex-col items-center justify-center px-4 animate-fadeIn">
      <div className="absolute inset-0 opacity-10 bg-[url('https://images.pexels.com/photos/1590644/pexels-photo-1590644.jpeg')] bg-cover bg-center"></div>
      <div className="absolute inset-0 bg-gradient-radial from-transparent to-gray-900 opacity-80"></div>
      
      <div className="absolute top-4 right-4">
        <LanguageSelector />
      </div>
      
      <div className="z-10 w-full max-w-md bg-gray-900 bg-opacity-80 backdrop-blur-sm p-8 rounded-xl border border-gray-800 shadow-2xl">
        <div className="text-center mb-8 animate-fadeInUp">
          <div className="flex justify-center mb-4">
            <div className="relative">
              <Target size={56} className="text-red-600" />
              <Users size={32} className="text-white absolute -bottom-2 -right-2" />
            </div>
          </div>
          <h1 className="font-serif text-3xl sm:text-4xl font-bold text-white mb-2">{t.welcome.title}</h1>
          <p className="text-gray-400 text-sm sm:text-base">{t.welcome.subtitle}</p>
          <div className="mt-2 flex items-center justify-center text-sm text-gray-500">
            <Activity size={16} className="text-green-500 mr-1" />
            <span>{activePlayerCount} players online</span>
          </div>
        </div>
        
        <UsernameForm onSubmit={handleUsernameSubmit} />
        
        <div className="mt-6 flex flex-col items-center gap-4">
          <button
            onClick={() => setShowRolesGuide(true)}
            className="text-gray-400 hover:text-white transition-colors flex items-center gap-2"
          >
            <Book size={20} />
            <span>{t.welcome.viewRoleGuide}</span>
          </button>
          <p className="text-gray-500 text-xs">{t.welcome.agreeToRules}</p>
        </div>
      </div>

      <RolesGuide isOpen={showRolesGuide} onClose={() => setShowRolesGuide(false)} />
    </div>
  );
};

export default WelcomeScreen;