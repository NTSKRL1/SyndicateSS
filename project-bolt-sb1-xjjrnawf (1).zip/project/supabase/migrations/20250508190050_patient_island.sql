-- Enable real-time for players table
ALTER PUBLICATION supabase_realtime ADD TABLE players;

-- Enable real-time for specific operations
ALTER TABLE players REPLICA IDENTITY FULL;

COMMENT ON TABLE players IS '@realtime={"*":true}';

-- Ensure proper replication settings
DO $$
BEGIN
  -- Enable real-time for INSERT
  EXECUTE format('ALTER TABLE %I.%I ENABLE REPLICA IDENTITY FULL', 'public', 'players');
END $$;