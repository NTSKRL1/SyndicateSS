/*
  # Fix RLS policies for rooms table

  1. Changes
    - Drop existing RLS policies for rooms table
    - Create new policies with proper authentication checks
    - Ensure authenticated users can create and manage rooms
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Anyone can read rooms" ON rooms;
DROP POLICY IF EXISTS "Authenticated users can create rooms" ON rooms;
DROP POLICY IF EXISTS "Host can update room" ON rooms;

-- Create new policies
CREATE POLICY "Enable read access for all users"
  ON rooms FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Enable insert for authenticated users"
  ON rooms FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Enable update for room hosts"
  ON rooms FOR UPDATE
  TO authenticated
  USING (auth.uid()::text = host)
  WITH CHECK (auth.uid()::text = host);

CREATE POLICY "Enable delete for room hosts"
  ON rooms FOR DELETE
  TO authenticated
  USING (auth.uid()::text = host);