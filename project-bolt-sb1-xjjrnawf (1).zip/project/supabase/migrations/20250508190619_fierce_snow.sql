/*
  # Add inactive player cleanup function
  
  1. Changes
    - Create function to identify and clean up inactive players
    - Add index on last_active column for better performance
    - Update cleanup trigger to use new function
*/

-- Add index on last_active for better performance
CREATE INDEX IF NOT EXISTS idx_players_last_active ON players(last_active);

-- Create function to identify inactive players
CREATE OR REPLACE FUNCTION get_inactive_players()
RETURNS TABLE (
  id uuid,
  username text,
  last_active timestamptz
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id,
    p.username,
    p.last_active
  FROM players p
  WHERE p.last_active < NOW() - INTERVAL '5 minutes'
  AND p.room_id = 'MAINGAME'
  AND p.username != (
    SELECT host 
    FROM rooms 
    WHERE id = 'MAINGAME'
  );
END;
$$ LANGUAGE plpgsql;

-- Update cleanup function to use the new inactive player function
CREATE OR REPLACE FUNCTION cleanup_inactive_players()
RETURNS void AS $$
DECLARE
  inactive_count integer;
BEGIN
  -- Delete inactive players
  WITH deleted AS (
    DELETE FROM players
    WHERE (id, username, last_active) IN (
      SELECT * FROM get_inactive_players()
    )
    RETURNING id
  )
  SELECT COUNT(*) INTO inactive_count FROM deleted;

  -- Log cleanup for monitoring
  INSERT INTO game_events (
    room_id,
    event_type,
    data
  ) VALUES (
    'MAINGAME',
    'player_cleanup',
    jsonb_build_object(
      'inactive_players_removed', inactive_count,
      'timestamp', NOW()
    )
  );
  
  -- Reset host to system if no players remain
  UPDATE rooms 
  SET host = 'system'
  WHERE id = 'MAINGAME'
  AND NOT EXISTS (
    SELECT 1 
    FROM players 
    WHERE room_id = 'MAINGAME'
  );
END;
$$ LANGUAGE plpgsql;