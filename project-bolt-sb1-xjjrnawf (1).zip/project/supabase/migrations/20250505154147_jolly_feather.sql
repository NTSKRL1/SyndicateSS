/*
  # Update RLS policies for single room implementation

  1. Changes
    - Drop existing policies
    - Add new policies for room management
    - Allow any authenticated user to become host if no host exists
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Enable read access for all users" ON rooms;
DROP POLICY IF EXISTS "Enable room creation" ON rooms;
DROP POLICY IF EXISTS "Enable host management" ON rooms;
DROP POLICY IF EXISTS "Host can delete room" ON rooms;

-- Create new policies
CREATE POLICY "Enable read access for all users"
ON rooms FOR SELECT
TO public
USING (true);

CREATE POLICY "Enable room creation"
ON rooms FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "Enable host management"
ON rooms FOR UPDATE
TO authenticated
USING (true)
WITH CHECK (true);

-- Update players policies
DROP POLICY IF EXISTS "Anyone can read players" ON players;
DROP POLICY IF EXISTS "Authenticated users can join as players" ON players;
DROP POLICY IF EXISTS "Players can update themselves" ON players;

CREATE POLICY "Anyone can read players"
ON players FOR SELECT
TO public
USING (true);

CREATE POLICY "Authenticated users can join as players"
ON players FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "Players can update themselves"
ON players FOR UPDATE
TO authenticated
USING (true);