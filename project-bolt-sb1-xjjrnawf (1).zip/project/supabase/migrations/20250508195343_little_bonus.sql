-- Delete inactive players using CTEs to avoid ambiguous references
WITH current_host AS (
  SELECT host 
  FROM rooms 
  WHERE id = 'MAINGAME'
),
inactive_players AS (
  SELECT p.username
  FROM players p
  WHERE p.room_id = 'MAINGAME'
  AND p.last_active < NOW() - INTERVAL '2 minutes'
  AND p.username != (SELECT host FROM current_host)
)
DELETE FROM players p
WHERE p.username IN (SELECT username FROM inactive_players);

-- Reset host to system if no players remain
WITH player_check AS (
  SELECT 1 
  FROM players p
  WHERE p.room_id = 'MAINGAME'
  LIMIT 1
)
UPDATE rooms r
SET host = 'system'
WHERE r.id = 'MAINGAME'
AND NOT EXISTS (SELECT 1 FROM player_check);