/*
  # Clear all inactive players
  
  1. Changes
    - Delete all players from the MAINGAME room
    - Reset the room host to system
*/

-- Delete all players from MAINGAME room
DELETE FROM players 
WHERE room_id = 'MAINGAME';

-- Reset the room host
UPDATE rooms 
SET host = 'system'
WHERE id = 'MAINGAME';