/*
  # Fix Room Level Security Policies

  1. Changes
    - Update RLS policies for rooms table to allow authenticated users to:
      - Create rooms (when they are the host)
      - Read rooms (for all users)
      - Update rooms (when they are the host)
      - Delete rooms (when they are the host)

  2. Security
    - Enable RLS on rooms table (already enabled)
    - Add policies for CRUD operations with appropriate conditions
*/

-- Drop existing policies to recreate them with correct permissions
DROP POLICY IF EXISTS "Anyone can read rooms" ON rooms;
DROP POLICY IF EXISTS "Authenticated users can create rooms" ON rooms;
DROP POLICY IF EXISTS "Host can update room" ON rooms;

-- Create new policies with correct permissions
CREATE POLICY "Anyone can read rooms"
ON rooms
FOR SELECT
TO public
USING (true);

CREATE POLICY "Authenticated users can create rooms"
ON rooms
FOR INSERT
TO authenticated
WITH CHECK (auth.uid()::text = host);

CREATE POLICY "Host can update room"
ON rooms
FOR UPDATE
TO authenticated
USING (auth.uid()::text = host)
WITH CHECK (auth.uid()::text = host);

CREATE POLICY "Host can delete room"
ON rooms
FOR DELETE
TO authenticated
USING (auth.uid()::text = host);