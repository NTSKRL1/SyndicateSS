/*
  # Add room creation policy

  1. Security Changes
    - Add policy to allow authenticated users to create rooms
    - Policy ensures host field matches the authenticated user's ID
*/

CREATE POLICY "Enable room creation for authenticated users"
ON public.rooms
FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid()::text = host
);