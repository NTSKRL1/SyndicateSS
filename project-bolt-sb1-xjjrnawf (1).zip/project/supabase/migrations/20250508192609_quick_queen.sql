/*
  # Clean up inactive players
  
  1. Changes
    - Delete inactive players except host
    - Reset host if no players remain
    - Use proper table aliases to avoid ambiguous column references
*/

-- Delete all existing players except the host
WITH current_host AS (
  SELECT host 
  FROM rooms r
  WHERE r.id = 'MAINGAME'
)
DELETE FROM players p
WHERE p.room_id = 'MAINGAME'
AND p.username != (SELECT host FROM current_host);

-- Reset host to system if no players remain
UPDATE rooms r
SET host = 'system'
WHERE r.id = 'MAINGAME'
AND NOT EXISTS (
  SELECT 1 
  FROM players p
  WHERE p.room_id = r.id
);