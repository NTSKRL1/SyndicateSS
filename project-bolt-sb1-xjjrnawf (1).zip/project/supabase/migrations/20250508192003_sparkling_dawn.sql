-- Execute cleanup of inactive players
SELECT cleanup_inactive_players();

-- Delete all existing players except the host
DELETE FROM players 
WHERE room_id = 'MAINGAME'
AND username != (
  SELECT host 
  FROM rooms 
  WHERE id = 'MAINGAME'
);

-- Reset host to system if no players remain
UPDATE rooms 
SET host = 'system'
WHERE id = 'MAINGAME'
AND NOT EXISTS (
  SELECT 1 
  FROM players 
  WHERE room_id = 'MAINGAME'
);