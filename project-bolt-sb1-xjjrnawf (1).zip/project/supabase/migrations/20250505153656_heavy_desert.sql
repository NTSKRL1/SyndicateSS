/*
  # Fix room creation policy

  1. Changes
    - Drop existing room creation policy
    - Recreate policy with correct permissions
  
  2. Security
    - Maintains RLS enabled on rooms table
    - Ensures authenticated users can create rooms
    - Validates that room creator is set as host
*/

-- Drop existing policy if it exists
DROP POLICY IF EXISTS "Enable room creation for authenticated users" ON rooms;

-- Create new policy
CREATE POLICY "Enable room creation for authenticated users"
ON rooms
FOR INSERT
TO authenticated
WITH CHECK (auth.uid()::text = host);