/*
  # Add room creation policy

  1. Security Changes
    - Add RLS policy to allow authenticated users to create rooms
    - Policy ensures users can only create rooms where they are the host
*/

CREATE POLICY "Enable room creation for authenticated users"
ON public.rooms
FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid()::text = host
);