/*
  # Clean up inactive players
  
  1. Changes
    - Delete inactive players except host
    - Reset host if no players remain
    - Use CTEs and proper table aliases to avoid ambiguous references
*/

-- Delete inactive players using CTE for clarity and to avoid ambiguous references
WITH current_host AS (
  SELECT host 
  FROM rooms 
  WHERE id = 'MAINGAME'
)
DELETE FROM players p
WHERE p.room_id = 'MAINGAME'
AND p.username != (SELECT host FROM current_host);

-- Reset host to system if no players remain
WITH player_check AS (
  SELECT 1 
  FROM players p
  WHERE p.room_id = 'MAINGAME'
  LIMIT 1
)
UPDATE rooms r
SET host = 'system'
WHERE r.id = 'MAINGAME'
AND NOT EXISTS (SELECT 1 FROM player_check);