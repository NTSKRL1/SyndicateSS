/*
  # Add last_active column to players table
  
  1. Changes
    - Add last_active column to players table with default value of now()
    - Column will be used to track player activity
  
  2. Security
    - Maintains existing RLS policies
    - Safe addition of new column
*/

-- Add last_active column to players table
ALTER TABLE players ADD COLUMN last_active timestamptz DEFAULT now();

-- Update existing players' last_active to current timestamp
UPDATE players SET last_active = now();

-- Create function to update last_active
CREATE OR REPLACE FUNCTION update_player_last_active()
RETURNS TRIGGER AS $$
BEGIN
  NEW.last_active = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to automatically update last_active
CREATE TRIGGER update_player_last_active
  BEFORE UPDATE ON players
  FOR EACH ROW
  EXECUTE FUNCTION update_player_last_active();