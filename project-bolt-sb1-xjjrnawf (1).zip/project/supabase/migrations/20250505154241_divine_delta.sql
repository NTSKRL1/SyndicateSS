/*
  # Update RLS policies for single server setup
  
  1. Changes
    - Drop all existing policies
    - Create new policies that allow:
      - Anyone to read rooms and players
      - Authenticated users to create/join rooms
      - Any authenticated user to update room (for host management)
    - Remove deletion policies since we keep one permanent room
*/

-- Drop all existing policies
DROP POLICY IF EXISTS "Enable read access for all users" ON rooms;
DROP POLICY IF EXISTS "Enable room creation" ON rooms;
DROP POLICY IF EXISTS "Enable host management" ON rooms;
DROP POLICY IF EXISTS "Enable room creation for authenticated users" ON rooms;
DROP POLICY IF EXISTS "Anyone can read players" ON players;
DROP POLICY IF EXISTS "Authenticated users can join as players" ON players;
DROP POLICY IF EXISTS "Players can update themselves" ON players;

-- Create new simplified policies for rooms
CREATE POLICY "Enable read access for all users"
ON rooms FOR SELECT
TO public
USING (true);

CREATE POLICY "Enable room creation and management"
ON rooms FOR ALL
TO authenticated
USING (true)
WITH CHECK (true);

-- Create new simplified policies for players
CREATE POLICY "Enable player access"
ON players FOR ALL
TO authenticated
USING (true)
WITH CHECK (true);

CREATE POLICY "Public can read players"
ON players FOR SELECT
TO public
USING (true);