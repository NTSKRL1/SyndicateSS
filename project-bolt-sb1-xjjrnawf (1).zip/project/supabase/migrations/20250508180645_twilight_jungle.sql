/*
  # Add automatic cleanup of inactive players
  
  1. Changes
    - Add function to clean up inactive players
    - Create trigger to run cleanup periodically
    - Set cleanup interval to 2 minutes
*/

-- Create function to clean up inactive players
CREATE OR REPLACE FUNCTION cleanup_inactive_players()
RETURNS void AS $$
BEGIN
  -- Delete players that haven't been active in the last 2 minutes
  DELETE FROM players 
  WHERE last_active < NOW() - INTERVAL '2 minutes'
  AND room_id = 'MAINGAME'
  AND username != (
    SELECT host 
    FROM rooms 
    WHERE id = 'MAINGAME'
  );
  
  -- Reset host to system if no players remain
  UPDATE rooms 
  SET host = 'system'
  WHERE id = 'MAINGAME'
  AND NOT EXISTS (
    SELECT 1 
    FROM players 
    WHERE room_id = 'MAINGAME'
  );
END;
$$ LANGUAGE plpgsql;

-- Create trigger function
CREATE OR REPLACE FUNCTION trigger_cleanup_inactive_players()
RETURNS trigger AS $$
BEGIN
  IF TG_OP = 'UPDATE' AND NEW.updated_at > OLD.updated_at THEN
    PERFORM cleanup_inactive_players();
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to run cleanup on room updates
DROP TRIGGER IF EXISTS trigger_cleanup_inactive_players ON rooms;
CREATE TRIGGER trigger_cleanup_inactive_players
  AFTER UPDATE ON rooms
  FOR EACH ROW
  EXECUTE FUNCTION trigger_cleanup_inactive_players();