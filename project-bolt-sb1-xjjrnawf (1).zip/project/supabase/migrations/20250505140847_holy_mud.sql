/*
  # Fix RLS policies for rooms table

  1. Changes
    - Drop existing INSERT policies that are causing conflicts
    - Add new INSERT policy allowing authenticated users to create rooms
    - Ensure host field matches the authenticated user's ID
  
  2. Security
    - Maintains RLS enabled on rooms table
    - Ensures only authenticated users can create rooms
    - Validates that room creator is set as host
*/

-- Drop existing conflicting policies
DROP POLICY IF EXISTS "Enable room creation for authenticated users" ON rooms;
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON rooms;

-- Create new INSERT policy
CREATE POLICY "Enable room creation for authenticated users"
ON rooms
FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid()::text = host
);