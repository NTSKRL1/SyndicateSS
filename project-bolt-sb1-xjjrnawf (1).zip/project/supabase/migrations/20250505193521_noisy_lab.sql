/*
  # Clean up existing players
  
  1. Changes
    - Remove all existing players from the MAINGAME room
    - Reset the room's host to 'system'
*/

-- Delete all existing players
DELETE FROM players 
WHERE room_id = 'MAINGAME';

-- Reset the room host
UPDATE rooms 
SET host = 'system'
WHERE id = 'MAINGAME';