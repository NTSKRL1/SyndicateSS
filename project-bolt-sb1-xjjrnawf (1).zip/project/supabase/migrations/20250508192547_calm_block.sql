/*
  # Clean up inactive players
  
  1. Changes
    - Delete inactive players except host
    - Reset host to system if no players remain
    - Use table aliases to avoid ambiguous column references
*/

-- Delete all existing players except the host
DELETE FROM players p
WHERE p.room_id = 'MAINGAME'
AND p.username != (
  SELECT r.host 
  FROM rooms r
  WHERE r.id = 'MAINGAME'
);

-- Reset host to system if no players remain
UPDATE rooms r
SET host = 'system'
WHERE r.id = 'MAINGAME'
AND NOT EXISTS (
  SELECT 1 
  FROM players p
  WHERE p.room_id = r.id
);