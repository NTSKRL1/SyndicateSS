/*
  # Fix cleanup trigger for inactive players
  
  1. Changes
    - Remove recursive trigger that was causing stack overflow
    - Add direct cleanup function for inactive players
    - Maintain host management functionality
    
  2. Security
    - Safe deletion of inactive players
    - Proper host management
*/

-- Delete all existing players from MAINGAME room
DELETE FROM players 
WHERE room_id = 'MAINGAME' 
AND created_at < NOW() - INTERVAL '5 minutes'
AND username != (SELECT host FROM rooms WHERE id = 'MAINGAME');

-- Reset host to system if no players remain
UPDATE rooms 
SET host = 'system'
WHERE id = 'MAINGAME'
AND NOT EXISTS (SELECT 1 FROM players WHERE room_id = 'MAINGAME');