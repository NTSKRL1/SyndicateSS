/*
  # Clean up inactive players
  
  1. Changes
    - Delete inactive players (those inactive for more than 2 minutes)
    - Preserve the host player
    - Reset host to 'system' if no players remain
    - Log cleanup events for monitoring
  
  2. Security
    - Safe deletion with proper checks
    - Maintains data integrity
    - Preserves host status
*/

-- Delete inactive players using CTEs for clarity and performance
WITH current_host AS (
  SELECT host 
  FROM rooms 
  WHERE id = 'MAINGAME'
),
inactive_players AS (
  SELECT p.id, p.username
  FROM players p
  WHERE p.room_id = 'MAINGAME'
  AND p.last_active < NOW() - INTERVAL '2 minutes'
  AND p.username != (SELECT host FROM current_host)
),
deleted_players AS (
  DELETE FROM players p
  WHERE p.id IN (SELECT id FROM inactive_players)
  RETURNING p.username
)
INSERT INTO game_events (
  room_id,
  event_type,
  data
)
SELECT 
  'MAINGAME',
  'player_cleanup',
  jsonb_build_object(
    'removed_players', array_agg(username),
    'count', count(*),
    'timestamp', NOW()
  )
FROM deleted_players
WHERE EXISTS (SELECT 1 FROM deleted_players);

-- Reset host to system if no players remain
WITH remaining_players AS (
  SELECT 1 
  FROM players p
  WHERE p.room_id = 'MAINGAME'
  LIMIT 1
)
UPDATE rooms r
SET host = 'system'
WHERE r.id = 'MAINGAME'
AND NOT EXISTS (SELECT 1 FROM remaining_players);