/*
  # Enable real-time functionality for players table
  
  1. Changes
    - Add players table to supabase_realtime publication
    - Set replica identity to full for complete change tracking
    - Enable real-time for all operations
*/

-- Add table to realtime publication if not already added
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime'
    AND schemaname = 'public'
    AND tablename = 'players'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE players;
  END IF;
END $$;

-- Set replica identity to full
ALTER TABLE players REPLICA IDENTITY FULL;

-- Add realtime comment
COMMENT ON TABLE players IS '@realtime={"*":true}';