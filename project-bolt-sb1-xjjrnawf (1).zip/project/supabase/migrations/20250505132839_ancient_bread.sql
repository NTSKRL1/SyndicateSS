/*
  # Update room ID schema

  1. Changes
    - Modify rooms table to use text for ID instead of UUID
    - Update foreign key constraints in related tables
*/

-- Temporarily disable RLS
ALTER TABLE rooms DISABLE ROW LEVEL SECURITY;
ALTER TABLE players DISABLE ROW LEVEL SECURITY;
ALTER TABLE game_events DISABLE ROW LEVEL SECURITY;
ALTER TABLE chat_messages DISABLE ROW LEVEL SECURITY;

-- Drop existing foreign key constraints
ALTER TABLE players DROP CONSTRAINT players_room_id_fkey;
ALTER TABLE game_events DROP CONSTRAINT game_events_room_id_fkey;
ALTER TABLE chat_messages DROP CONSTRAINT chat_messages_room_id_fkey;

-- Modify room_id columns to text
ALTER TABLE rooms ALTER COLUMN id TYPE text;
ALTER TABLE players ALTER COLUMN room_id TYPE text;
ALTER TABLE game_events ALTER COLUMN room_id TYPE text;
ALTER TABLE chat_messages ALTER COLUMN room_id TYPE text;

-- Recreate foreign key constraints
ALTER TABLE players ADD CONSTRAINT players_room_id_fkey 
  FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE CASCADE;
ALTER TABLE game_events ADD CONSTRAINT game_events_room_id_fkey 
  FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE CASCADE;
ALTER TABLE chat_messages ADD CONSTRAINT chat_messages_room_id_fkey 
  FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE CASCADE;

-- Re-enable RLS
ALTER TABLE rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE players ENABLE ROW LEVEL SECURITY;
ALTER TABLE game_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;