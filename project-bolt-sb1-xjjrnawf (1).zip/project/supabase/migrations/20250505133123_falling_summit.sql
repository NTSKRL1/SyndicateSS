/*
  # Fix database schema
  
  1. Changes
    - Drop existing tables and recreate with text IDs
    - Ensure proper cascade deletion
    - Re-enable RLS and policies
*/

-- Drop existing tables if they exist
DROP TABLE IF EXISTS chat_messages;
DROP TABLE IF EXISTS game_events;
DROP TABLE IF EXISTS players;
DROP TABLE IF EXISTS rooms;

-- Create rooms table
CREATE TABLE rooms (
  id text PRIMARY KEY,
  name text NOT NULL,
  host text NOT NULL,
  game_state text NOT NULL DEFAULT 'waiting',
  settings jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create players table
CREATE TABLE players (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  room_id text REFERENCES rooms(id) ON DELETE CASCADE,
  username text NOT NULL,
  role text,
  is_alive boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- Create game_events table
CREATE TABLE game_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  room_id text REFERENCES rooms(id) ON DELETE CASCADE,
  event_type text NOT NULL,
  data jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

-- Create chat_messages table
CREATE TABLE chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  room_id text REFERENCES rooms(id) ON DELETE CASCADE,
  sender text NOT NULL,
  content text NOT NULL,
  chat_type text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE players ENABLE ROW LEVEL SECURITY;
ALTER TABLE game_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can read rooms"
  ON rooms FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can create rooms"
  ON rooms FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Host can update room"
  ON rooms FOR UPDATE
  TO authenticated
  USING (auth.uid()::text = host);

CREATE POLICY "Anyone can read players"
  ON players FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can join as players"
  ON players FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Players can update themselves"
  ON players FOR UPDATE
  TO authenticated
  USING (auth.uid()::text = username);

CREATE POLICY "Anyone can read game events"
  ON game_events FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can create game events"
  ON game_events FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Anyone can read chat messages"
  ON chat_messages FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can send messages"
  ON chat_messages FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Create function to update room timestamp
CREATE OR REPLACE FUNCTION update_room_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for updating room timestamp
CREATE TRIGGER update_room_timestamp
  BEFORE UPDATE ON rooms
  FOR EACH ROW
  EXECUTE FUNCTION update_room_timestamp();