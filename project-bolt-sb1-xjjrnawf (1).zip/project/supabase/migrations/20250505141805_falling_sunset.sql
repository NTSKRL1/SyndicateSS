/*
  # Fix room and player policies

  1. Changes
    - Drop and recreate all room policies
    - Update player policies for proper access control
    - Ensure no policy conflicts
  
  2. Security
    - Maintain RLS on all tables
    - Allow public read access
    - Restrict modifications to authenticated users
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Enable read access for all users" ON rooms;
DROP POLICY IF EXISTS "Enable room creation" ON rooms;
DROP POLICY IF EXISTS "Enable host management" ON rooms;
DROP POLICY IF EXISTS "Enable host deletion" ON rooms;
DROP POLICY IF EXISTS "Host can delete room" ON rooms;

-- Create new room policies
CREATE POLICY "Enable read access for all users"
ON rooms FOR SELECT
TO public
USING (true);

CREATE POLICY "Enable room creation"
ON rooms FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "Enable host management"
ON rooms FOR UPDATE
TO authenticated
USING (auth.uid()::text = host)
WITH CHECK (auth.uid()::text = host);

CREATE POLICY "Host can delete room"
ON rooms FOR DELETE
TO authenticated
USING ((auth.uid())::text = host);

-- Update players table policies
DROP POLICY IF EXISTS "Anyone can read players" ON players;
DROP POLICY IF EXISTS "Authenticated users can join as players" ON players;
DROP POLICY IF EXISTS "Players can update themselves" ON players;

CREATE POLICY "Anyone can read players"
ON players FOR SELECT
TO public
USING (true);

CREATE POLICY "Authenticated users can join as players"
ON players FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "Players can update themselves"
ON players FOR UPDATE
TO authenticated
USING (auth.uid()::text = username);