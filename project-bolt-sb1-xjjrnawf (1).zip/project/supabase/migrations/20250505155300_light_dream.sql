/*
  # Update database for single server setup
  
  1. Changes
    - Drop existing policies
    - Add simplified policies for single server
    - Create main game room with temporary host
*/

-- Drop all existing policies
DROP POLICY IF EXISTS "Enable read access for all users" ON rooms;
DROP POLICY IF EXISTS "Enable room management" ON rooms;
DROP POLICY IF EXISTS "Enable player management" ON players;
DROP POLICY IF EXISTS "Public can read players" ON players;

-- Create simplified policies for rooms
CREATE POLICY "Enable read access for all users"
ON rooms FOR SELECT
TO public
USING (true);

CREATE POLICY "Enable room management"
ON rooms FOR ALL
TO authenticated
WITH CHECK (true);

-- Create simplified policies for players
CREATE POLICY "Enable player management"
ON players FOR ALL
TO authenticated
WITH CHECK (true);

CREATE POLICY "Public can read players"
ON players FOR SELECT
TO public
USING (true);

-- Create main game room if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM rooms WHERE id = 'MAINGAME') THEN
    INSERT INTO rooms (id, name, host, game_state, settings)
    VALUES (
      'MAINGAME',
      'Game Room',
      'system',  -- Temporary host that will be updated when first player joins
      'waiting',
      jsonb_build_object(
        'enabledRoles', jsonb_build_array(
          'classic-syndicate',
          'flash',
          'vanished',
          'blackmailer',
          'detective',
          'seer',
          'trapper',
          'veteran',
          'jailor',
          'classic-savior',
          'vigilante',
          'doctor'
        ),
        'confirmEjects', true,
        'anonymousVoting', false
      )
    );
  END IF;
END $$;