/*
  # Clean up inactive players
  
  1. Changes
    - Remove inactive players from MAINGAME room
    - Reset host if no players remain
    - Fix ambiguous column references
*/

-- Delete all existing players except the host
DELETE FROM players p
WHERE p.room_id = 'MAINGAME'
AND p.username != (
  SELECT r.host 
  FROM rooms r
  WHERE r.id = 'MAINGAME'
);

-- Reset host to system if no players remain
UPDATE rooms r
SET host = 'system'
WHERE r.id = 'MAINGAME'
AND NOT EXISTS (
  SELECT 1 
  FROM players p
  WHERE p.room_id = r.id
);