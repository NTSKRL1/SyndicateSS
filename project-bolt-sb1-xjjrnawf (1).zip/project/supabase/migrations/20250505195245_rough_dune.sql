/*
  # Add cleanup trigger for inactive players
  
  1. Changes
    - Create function to cleanup inactive players
    - Create trigger function that will be called by the trigger
    - Add trigger on rooms table
    - Run initial cleanup
  
  2. Security
    - Functions run with proper permissions
    - Safe deletion of inactive players
*/

-- Function to cleanup inactive players
CREATE OR REPLACE FUNCTION cleanup_inactive_players()
RETURNS void AS $$
BEGIN
  -- Delete players that aren't in any active room
  DELETE FROM players
  WHERE room_id NOT IN (SELECT id FROM rooms);
  
  -- Delete players from rooms that haven't been updated in 24 hours
  DELETE FROM players
  WHERE room_id IN (
    SELECT id FROM rooms 
    WHERE updated_at < NOW() - INTERVAL '24 hours'
  );
END;
$$ LANGUAGE plpgsql;

-- Function that will be called by the trigger
CREATE OR REPLACE FUNCTION trigger_cleanup_inactive_players()
RETURNS trigger AS $$
BEGIN
  PERFORM cleanup_inactive_players();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to cleanup inactive players
DROP TRIGGER IF EXISTS trigger_cleanup_inactive_players ON rooms;
CREATE TRIGGER trigger_cleanup_inactive_players
  AFTER UPDATE ON rooms
  FOR EACH ROW
  EXECUTE FUNCTION trigger_cleanup_inactive_players();

-- Run initial cleanup
SELECT cleanup_inactive_players();