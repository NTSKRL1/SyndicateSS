/*
  # Update players table RLS policies for public access
  
  1. Changes
    - Enable RLS on players table
    - Add policies for public access without auth requirements
    - Allow all CRUD operations for gameplay functionality
  
  2. Security
    - No authentication required
    - Policies allow necessary game operations
*/

-- Enable RLS on players table
ALTER TABLE players ENABLE ROW LEVEL SECURITY;

-- Drop any existing policies
DROP POLICY IF EXISTS "Enable player access" ON players;
DROP POLICY IF EXISTS "Public can read players" ON players;
DROP POLICY IF EXISTS "Authenticated users can join as players" ON players;
DROP POLICY IF EXISTS "Players can update themselves" ON players;

-- Create new public access policy
CREATE POLICY "Enable public access to players"
ON players FOR ALL
TO public
USING (true)
WITH CHECK (true);