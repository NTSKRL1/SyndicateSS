-- Add table to realtime publication if not already added
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime'
    AND schemaname = 'public'
    AND tablename = 'players'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE players;
  END IF;
END $$;

-- Set replica identity to full for the players table
ALTER TABLE players REPLICA IDENTITY FULL;

-- Add realtime comment to enable all operations
COMMENT ON TABLE players IS '@realtime={"*":true}';