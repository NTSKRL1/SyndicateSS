/*
  # Add inactive player cleanup function
  
  1. Changes
    - Add function to delete inactive players
    - Add trigger to automatically clean up inactive players
    - Update existing cleanup function
*/

-- Create function to delete inactive players
CREATE OR REPLACE FUNCTION delete_inactive_players()
RETURNS void AS $$
BEGIN
  -- Delete players that haven't been active in the last 2 minutes
  DELETE FROM players 
  WHERE last_active < NOW() - INTERVAL '2 minutes'
  AND room_id = 'MAINGAME'
  AND username != (
    SELECT host 
    FROM rooms 
    WHERE id = 'MAINGAME'
  );
END;
$$ LANGUAGE plpgsql;

-- Update cleanup function to include inactive player deletion
CREATE OR REPLACE FUNCTION cleanup_inactive_players()
RETURNS void AS $$
BEGIN
  -- Delete inactive players
  PERFORM delete_inactive_players();
  
  -- Reset host to system if no players remain
  UPDATE rooms 
  SET host = 'system'
  WHERE id = 'MAINGAME'
  AND NOT EXISTS (
    SELECT 1 
    FROM players 
    WHERE room_id = 'MAINGAME'
  );
END;
$$ LANGUAGE plpgsql;