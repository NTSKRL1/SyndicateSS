/*
  # Update players table RLS policies for public access
  
  1. Changes
    - Drop existing policies to avoid conflicts
    - Enable RLS on players table
    - Create new policy for unrestricted public access
    
  2. Security
    - Allows all operations (SELECT, INSERT, UPDATE, DELETE) without authentication
    - Suitable for public games without user authentication
*/

-- Drop any existing policies to avoid conflicts
DROP POLICY IF EXISTS "Enable public access to players" ON players;
DROP POLICY IF EXISTS "Enable player access" ON players;
DROP POLICY IF EXISTS "Public can read players" ON players;
DROP POLICY IF EXISTS "Authenticated users can join as players" ON players;
DROP POLICY IF EXISTS "Players can update themselves" ON players;
DROP POLICY IF EXISTS "Allow insert for all" ON players;
DROP POLICY IF EXISTS "Allow select for all" ON players;
DROP POLICY IF EXISTS "Allow update for all" ON players;
DROP POLICY IF EXISTS "Allow delete for all" ON players;

-- Enable RLS on players table
ALTER TABLE players ENABLE ROW LEVEL SECURITY;

-- Create a single policy that enables all operations for public access
CREATE POLICY "Enable unrestricted public access"
ON players
FOR ALL
TO public
USING (true)
WITH CHECK (true);