/*
  # Fix room creation policies

  1. Changes
    - Drop all existing room policies to avoid conflicts
    - Create new simplified policies with correct permissions
    - Ensure authenticated users can create rooms
*/

-- Drop all existing room policies to start fresh
DROP POLICY IF EXISTS "Enable read access for all users" ON rooms;
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON rooms;
DROP POLICY IF EXISTS "Enable update for room hosts" ON rooms;
DROP POLICY IF EXISTS "Enable delete for room hosts" ON rooms;
DROP POLICY IF EXISTS "Enable room creation for authenticated users" ON rooms;

-- Create new simplified policies
CREATE POLICY "Enable read access for all users"
ON rooms FOR SELECT
TO public
USING (true);

CREATE POLICY "Enable room creation"
ON rooms FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "Enable host management"
ON rooms FOR UPDATE
TO authenticated
USING (auth.uid()::text = host)
WITH CHECK (auth.uid()::text = host);

CREATE POLICY "Enable host deletion"
ON rooms FOR DELETE
TO authenticated
USING (auth.uid()::text = host);