/*
  # Cleanup inactive players
  
  1. Changes
    - Add function to clean up inactive players
    - Add trigger to automatically clean up when rooms are updated
    - Perform initial cleanup
  
  2. Security
    - Maintains RLS policies
    - Safe deletion of inactive records
*/

-- Function to mark players for cleanup
CREATE OR REPLACE FUNCTION cleanup_inactive_players()
RETURNS void AS $$
BEGIN
  -- Delete players that aren't in any active room
  DELETE FROM players
  WHERE room_id NOT IN (SELECT id FROM rooms);
  
  -- Delete players from rooms that haven't been updated in 24 hours
  DELETE FROM players
  WHERE room_id IN (
    SELECT id FROM rooms 
    WHERE updated_at < NOW() - INTERVAL '24 hours'
  );
END;
$$ LANGUAGE plpgsql;

-- Function for the trigger
CREATE OR REPLACE FUNCTION trigger_cleanup_inactive_players()
RETURNS trigger AS $$
BEGIN
  PERFORM cleanup_inactive_players();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to cleanup inactive players
DROP TRIGGER IF EXISTS trigger_cleanup_inactive_players ON rooms;
CREATE TRIGGER trigger_cleanup_inactive_players
  AFTER UPDATE ON rooms
  FOR EACH ROW
  EXECUTE FUNCTION trigger_cleanup_inactive_players();

-- Run initial cleanup
SELECT cleanup_inactive_players();